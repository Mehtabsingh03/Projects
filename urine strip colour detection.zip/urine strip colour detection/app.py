from flask import Flask, request, jsonify
import cv2
import numpy as np

app = Flask(__name__)

@app.route('/upload-image', methods=['POST'])
def upload_image():
    img = request.files['image']
    # Convert the image to HSV color space
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    # Define the color ranges
    lower_white = np.array([0, 0, 200])
    upper_white = np.array([255, 30, 255])

    lower_gray = np.array([0, 0, 100])
    upper_gray = np.array([150, 30, 150])

    lower_purple = np.array([120, 50, 50])
    upper_purple = np.array([150, 150, 150])

    lower_orange = np.array([5, 100, 50])
    upper_orange = np.array([30, 255, 255])

    lower_brown = np.array([10, 30, 0])
    upper_brown = np.array([25, 80, 50])

    lower_red = np.array([0, 120, 70])
    upper_red = np.array([10, 255, 255])

    lower_pink = np.array([145, 50, 200])
    upper_pink = np.array([179, 150, 255])

    lower_blue = np.array([100, 100, 50])
    upper_blue = np.array([130, 255, 255])

    lower_green = np.array([40, 50, 50])
    upper_green = np.array([70, 255, 255])

    lower_yellow = np.array([20, 50, 100])
    upper_yellow = np.array([35, 255, 255])

    # Create the masks containing the colors range
    mask_white = cv2.inRange(hsv, lower_white, upper_white)
    mask_gray = cv2.inRange(hsv, lower_gray, upper_gray)
    mask_purple = cv2.inRange(hsv, lower_purple, upper_purple)
    mask_orange = cv2.inRange(hsv, lower_orange, upper_orange)
    mask_brown = cv2.inRange(hsv, lower_brown, upper_brown)
    mask_red = cv2.inRange(hsv, lower_red, upper_red)
    mask_pink = cv2.inRange(hsv, lower_pink, upper_pink)
    mask_blue = cv2.inRange(hsv, lower_blue, upper_blue)
    mask_green = cv2.inRange(hsv, lower_green, upper_green)
    mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)


    # converting the mask to RGB
    mask_white_rgb = cv2.cvtColor(mask_white, cv2.COLOR_GRAY2RGB)
    mask_gray_rgb = cv2.cvtColor(mask_gray, cv2.COLOR_GRAY2RGB)
    mask_purple_rgb = cv2.cvtColor(mask_purple, cv2.COLOR_GRAY2RGB)
    mask_orange_rgb = cv2.cvtColor(mask_orange, cv2.COLOR_GRAY2RGB)
    mask_brown_rgb = cv2.cvtColor(mask_brown, cv2.COLOR_GRAY2RGB)
    mask_red_rgb = cv2.cvtColor(mask_red, cv2.COLOR_GRAY2RGB)
    mask_pink_rgb = cv2.cvtColor(mask_pink, cv2.COLOR_GRAY2RGB)
    mask_blue_rgb = cv2.cvtColor(mask_blue, cv2.COLOR_GRAY2RGB)
    mask_green_rgb = cv2.cvtColor(mask_green, cv2.COLOR_GRAY2RGB)
    mask_yellow_rgb = cv2.cvtColor(mask_yellow, cv2.COLOR_GRAY2RGB)

    my_dict = {
    'URO': mask_white_rgb,
    'BIL': mask_gray_rgb,
    'KET': mask_purple_rgb,
    'BLD': mask_orange_rgb,
    'PRO': mask_brown_rgb,
    'NIT': mask_red_rgb,
    'LEU': mask_pink_rgb,
    'GLU': mask_blue_rgb,
    'SG': mask_green_rgb,
    'PH': mask_yellow_rgb,    
    }

    #print range
    print(my_dict)

if __name__ == '__main__':
    app.run(debug=True)
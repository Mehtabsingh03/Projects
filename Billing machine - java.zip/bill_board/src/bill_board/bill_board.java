/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bill_board;


import java.awt.Component;
import java.awt.HeadlessException;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author MEHTAAB
 */
public class bill_board  implements sql{

    private static Component rootPane;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         try {
             Connection myconn = DriverManager.getConnection(mypath+mydb,myuser,mypass);
             try { String qry = "select * from users";
                    PreparedStatement st = myconn.prepareStatement(qry);
                    ResultSet rst = st.executeQuery();
                    if (rst.next()){
                        manage_login obj = new manage_login();
                        obj.setVisible(true);
                    }
                    else {
                        admin obj2 = new admin();
                        obj2.setVisible(true);
                    }
              
             
            }catch(Exception ex)
                {
                     JOptionPane.showMessageDialog(rootPane,"Database error : "+ex.getMessage());
                 }
         }catch(HeadlessException | SQLException ex)
         {
             JOptionPane.showMessageDialog(rootPane,"Database error : "+ex.getMessage());
         }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package bill_board;

/**
 *
 * @author MEHTAAB
 */
public interface sql {
      String mypath = "jdbc:mysql://localhost/";
            String mydb = "bill-board";
            String myuser = "root";
            String mypass = "";
            String default_img_name="default_user.png";
}

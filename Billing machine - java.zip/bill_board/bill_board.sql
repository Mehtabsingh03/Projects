-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2022 at 07:26 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bill_board`
--

-- --------------------------------------------------------

--
-- Table structure for table `cat`
--

CREATE TABLE `cat` (
  `catid` int(255) NOT NULL,
  `cat_name` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cat`
--

INSERT INTO `cat` (`catid`, `cat_name`) VALUES
(7, 'Shoes'),
(8, 'Shirts'),
(9, 'Jeans');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(100) NOT NULL,
  `catid` int(100) NOT NULL,
  `sub_id` int(100) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `price` float(22,2) NOT NULL,
  `Quantity` float(22,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `catid`, `sub_id`, `p_name`, `price`, `Quantity`) VALUES
(13, 7, 13, 'Sneakers_black', 1800.00, 19.00),
(14, 7, 13, 'Slip-Ons_greysss', 1200.00, 34.00),
(15, 7, 14, 'chelsea_brown', 1650.00, 22.00),
(16, 8, 15, 'cotton_stripped_black', 999.00, 30.00),
(17, 9, 18, 'bootcut_black', 3200.00, 35.00),
(18, 9, 18, 'skin_fit_white', 3420.00, 23.00),
(19, 9, 19, 'straight_blue(349.34.4)', 4345.00, 9.00),
(20, 7, 13, 'Sneakers_whites', 1900.00, 22.00),
(22, 7, 13, 'Slip-Ons_grey', 1200.00, 34.00);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `purid` int(222) NOT NULL,
  `supid` int(222) NOT NULL,
  `bill_date` date NOT NULL,
  `total_price` float(20,2) NOT NULL,
  `gst` float(22,2) NOT NULL,
  `total_bill` float(22,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purid`, `supid`, `bill_date`, `total_price`, `gst`, `total_bill`) VALUES
(27, 3, '2022-03-03', 3600.00, 180.00, 3780.00),
(28, 3, '2022-03-03', 3600.00, 180.00, 3780.00),
(29, 3, '2022-03-04', 3600.00, 180.00, 3780.00),
(30, 3, '2022-03-07', 9198.00, 459.90, 9657.90),
(31, 3, '2022-03-04', 1998.00, 99.90, 2097.90),
(32, 3, '2022-03-04', 16000.00, 800.00, 16800.00);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_details`
--

CREATE TABLE `purchase_details` (
  `sr_no.` int(11) NOT NULL,
  `pur_id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `p_name` varchar(111) NOT NULL,
  `Quantity` float(22,2) NOT NULL,
  `price` float(22,2) NOT NULL,
  `total_price` float(22,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchase_details`
--

INSERT INTO `purchase_details` (`sr_no.`, `pur_id`, `pid`, `p_name`, `Quantity`, `price`, `total_price`) VALUES
(7, 12, 13, 'Sneakers_black', 22.00, 1800.00, 39600.00),
(8, 12, 13, 'Sneakers_black', 22.00, 1800.00, 39600.00),
(9, 14, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(10, 14, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(11, 15, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(12, 16, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(13, 17, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(14, 18, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(15, 19, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(16, 20, 13, 'Sneakers_black', 1800.00, 2.00, 3600.00),
(17, 21, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(18, 22, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(19, 23, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(20, 24, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(21, 25, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(22, 26, 19, 'straight_blue(349.34.4)', 3.00, 4345.00, 13035.00),
(23, 27, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(24, 28, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(25, 29, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(26, 30, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(27, 30, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(28, 30, 16, 'cotton_stripped_black', 2.00, 999.00, 1998.00),
(29, 31, 16, 'cotton_stripped_black', 2.00, 999.00, 1998.00),
(30, 32, 17, 'bootcut_black', 3.00, 3200.00, 9600.00),
(31, 32, 17, 'bootcut_black', 2.00, 3200.00, 6400.00);

-- --------------------------------------------------------

--
-- Table structure for table `sell`
--

CREATE TABLE `sell` (
  `sell_id` int(11) NOT NULL,
  `bill_date` date NOT NULL,
  `total_price` float(22,2) NOT NULL,
  `gst` float(22,2) NOT NULL,
  `total_bill` float(22,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sell`
--

INSERT INTO `sell` (`sell_id`, `bill_date`, `total_price`, `gst`, `total_bill`) VALUES
(5, '2022-03-12', 1998.00, 99.90, 2097.90),
(6, '2022-03-05', 3600.00, 180.00, 3780.00),
(7, '2022-03-03', 9000.00, 450.00, 9450.00),
(8, '2022-03-03', 3600.00, 180.00, 3780.00);

-- --------------------------------------------------------

--
-- Table structure for table `sell_details`
--

CREATE TABLE `sell_details` (
  `sr_no.` int(11) NOT NULL,
  `sell_id` int(11) NOT NULL,
  `prodid` int(22) NOT NULL,
  `p_name` varchar(222) NOT NULL,
  `Quantity` float(22,2) NOT NULL,
  `price` float(22,2) NOT NULL,
  `total_price` float(22,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sell_details`
--

INSERT INTO `sell_details` (`sr_no.`, `sell_id`, `prodid`, `p_name`, `Quantity`, `price`, `total_price`) VALUES
(1, 1, 16, 'cotton_stripped_black', 2.00, 999.00, 1998.00),
(2, 2, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(3, 3, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(6, 6, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(7, 7, 13, 'Sneakers_black', 3.00, 1800.00, 5400.00),
(8, 7, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00),
(9, 8, 13, 'Sneakers_black', 2.00, 1800.00, 3600.00);

-- --------------------------------------------------------

--
-- Table structure for table `sub`
--

CREATE TABLE `sub` (
  `catid` int(11) NOT NULL,
  `sub_id` int(250) NOT NULL,
  `sub_name` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sub`
--

INSERT INTO `sub` (`catid`, `sub_id`, `sub_name`) VALUES
(7, 13, 'Casuals'),
(7, 14, 'Boots'),
(8, 15, 'casual'),
(9, 18, '32_waist');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `sid` int(100) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `phone` int(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pic` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sid`, `s_name`, `phone`, `address`, `pic`) VALUES
(3, 'jyoti_private_ltd', 2351223, 'jalandhar', '1646759640601default_user.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(111) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `gender` varchar(12) NOT NULL,
  `address` varchar(111) NOT NULL,
  `dob` date NOT NULL,
  `username` varchar(121) NOT NULL,
  `password` varchar(123) NOT NULL,
  `usertype` varchar(121) NOT NULL,
  `pic` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cat`
--
ALTER TABLE `cat`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`purid`);

--
-- Indexes for table `purchase_details`
--
ALTER TABLE `purchase_details`
  ADD PRIMARY KEY (`sr_no.`);

--
-- Indexes for table `sell`
--
ALTER TABLE `sell`
  ADD PRIMARY KEY (`sell_id`);

--
-- Indexes for table `sell_details`
--
ALTER TABLE `sell_details`
  ADD PRIMARY KEY (`sr_no.`);

--
-- Indexes for table `sub`
--
ALTER TABLE `sub`
  ADD PRIMARY KEY (`sub_id`),
  ADD KEY `catid` (`catid`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cat`
--
ALTER TABLE `cat`
  MODIFY `catid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `purid` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `purchase_details`
--
ALTER TABLE `purchase_details`
  MODIFY `sr_no.` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `sell`
--
ALTER TABLE `sell`
  MODIFY `sell_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sell_details`
--
ALTER TABLE `sell_details`
  MODIFY `sr_no.` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `sub`
--
ALTER TABLE `sub`
  MODIFY `sub_id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `sid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

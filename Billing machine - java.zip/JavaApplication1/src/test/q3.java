/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package test;
import java.util.Scanner;
/**
 *
 * @author MEHTAB
 */
public class q3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.print("\nEnter your name  ->");
        String a =scan.nextLine();
        // TODO code application logic here
        System.out.print("\nEnter your city name -->");
        String name =scan.nextLine();
        if (name.equals("jaipur")){
            System.out.println("Congrats, "+a+" you live in pink city");
            
        }
        else if (name.equals("jodhpur"))
        {
            System.out.println("Congrats "+a+" you live in blue city");
        }
        else 
        {
            System.out.println("Don't lose hope your city will be colourful soon");
        }
        
    }
    
}

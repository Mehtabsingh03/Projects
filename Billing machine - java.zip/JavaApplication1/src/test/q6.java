/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package test;

import java.util.Scanner;

/**
 *
 * @author MEHTAB
 */
public class q6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        // TODO code application logic here
         System.out.print("\n enter the  number for the patten to work till -> ");
        int a = scan.nextInt();
         int  c=(a/2);
        for (int i=1 ; i<=c+1 ; i++)
        {
            for (int p=1 ; p<=i; p++)
            {
                System.out.print(" ");
             
            }
            System.out.println("**");
            System.out.println("");
        }
         for (int i=c ; i>=1 ; i--)
        {
            for (int p=i ; p>=1; p--)
            {
                System.out.print(" ");
             
            }
            System.out.println("**");
            System.out.println("");
        }
    }
    
}

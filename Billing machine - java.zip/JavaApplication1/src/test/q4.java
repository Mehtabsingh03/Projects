/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package test;
import java.util.Scanner;
/**
 *
 * @author MEHTAB
 */
public class q4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        System.out.print("\nEnter the number  ->");
        int a=scan.nextInt();
        System.out.print("\nEnter the power  ->");
        int b=scan.nextInt();
       /* static int power(int a,int b)
        {
            return n;
        }*/
       int c=a;
        if (b==0)
           {
               a=1;
               
           }
           else if(b==1)
           {
               a=a;
               
           }
           else {
               
           
       for(int i=2;i<=b;i++)
       {
         a=c*a; 
          
       }
        
           }
        System.out.println("answer ="+a);
        
    }
    
}

 
package test;
 
import java.util.Scanner;

public class q1 {
 
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("enter string : ");
        String sen=scan.nextLine();
        String word[]=sen.split(" ");
        for(int i=0;i<word.length;i++)
        {
            char ch =word[i].charAt(0);
            ch = Character.toUpperCase(ch);
            String neww= ch+word[i].substring(1);
            word[i]=neww;
        }
        String fina = word[0]; 
        for(int i=1;i<word.length;i++)
        {
          fina = fina+" "+word[i];  
        }
        System.out.println("string : "+fina);
  
    }
    
}

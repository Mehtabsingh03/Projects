/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

/**
 *
 * @author MEHTAB
 */
public class great {
public static void great(int a,int b,int c)
    {
          if (a>b)
        {
            if (a>c)
            {
                System.out.println("value at a is greatest = "+a);
            }
            
        }
        else if (b>c)
        {
            System.out.println("value at b is greatest = "+b);
            
        }
        else 
        {
            System.out.println("value at c is greatest = "+c);
        }
    }
    
}

 
package packageX;
 
public interface kpo {
     float z=15.5f;
}

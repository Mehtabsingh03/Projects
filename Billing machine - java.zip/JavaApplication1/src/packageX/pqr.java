  
package packageX;

 
public interface pqr {
      float x=10.5f;
     float y=20.6f;
    
}

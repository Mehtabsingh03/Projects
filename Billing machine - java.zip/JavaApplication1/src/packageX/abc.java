 
package packageX;
 
/**
 *
 * @author MEHTAB
 */
public interface abc extends pqr,kpo 
{
      float p =17.8f;
    void sum();
}

 
package packaget;
import packageX.kpo;
import packageX.pqr;
import packageX.abc;
import two.ttt;

         

   class mnp extends ttt implements kpo,pqr,abc
  {

    @Override
    public void sum() {
        System.out.println("sum ="+(x+y+z+p));
    }

    @Override
   public void greatest(int a, int b, int c) {
         
           if (a>b)
        {
            if (a>c)
            {
                System.out.println("value at a is greatest from first 3  =  "+a);
            }
            
        }
        else if (b>c)
        {
            System.out.println("value at b is greatest from first 3 =  "+b);
            
        }
        else 
        {
            System.out.println("value at c is greatest from first 3  =  "+c);
        }
       }
  }     
      
  


 
public class test {

    
    public static void main(String[] args) {
        // TODO code application logic here
        mnp obj = new mnp();
        obj.greatest(56,345,35326);
        obj.sum();
        obj.lowest(24, 23502,325);
       // ttt tegveer = new ttt(324,24,235,35,35);
        
    }
    
}

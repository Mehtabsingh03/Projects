 
try{ 
       Connection myconn = DriverManager.getConnection(mypath+mydb,myuser,mypass);
   
        try{
            String qry = "select * from cat";
            PreparedStatement st =  myconn.prepareStatement(qry);
            ResultSet rst = st.executeQuery();
             
}catch(Exception ex)
{
    JOptionPane.showMessageDialog(rootPane,"Insertion error :"+ex.getMessage());
}
   
       
}catch(Exception ex)
{
    JOptionPane.showMessageDialog(rootPane,"Database error :"+ex.getMessage());
}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


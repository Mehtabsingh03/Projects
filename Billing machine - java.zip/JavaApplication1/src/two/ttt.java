 
package two;
import one.ttt;

 
public abstract class ttt extends ttt
{
   abstract public void greatest(int a,int b,int c);
  public void lowest(int a,int b,int c){
        if (a<b)
        {
            if (a<c)
            {
                System.out.println("value lowest  =  "+a);
            }
            
        }
        else if (b<c)
        {
            System.out.println("value lowest =  "+b);
            
        }
        else 
        {
            System.out.println("value  lowest =  "+c);
     
        }
  }
           
}
  

 
package one;

 
public class ttt {
     public ttt(float x,float y,float z,float a,float b){
         System.out.println("average =="+((a+b+x+y+z)/5));
     }
     
    
}

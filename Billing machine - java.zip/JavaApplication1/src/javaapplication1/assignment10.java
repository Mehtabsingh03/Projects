 
package javaapplication1;

import java.util.Scanner;
 

  interface myinterface
 {
     String username ="Mehtab Sandhu";
     void Calculate(float x,float y,float z);
 }
class first implements myinterface
{ 

    @Override
    public void Calculate(float x, float y, float z) {
         float average = x+y+z/3;
         System.out.println("welcome "+username);
         System.out.println("average = "+average);
    }
}

class second extends first {
    public void Calculate(float x,float y,float z){
        super.Calculate(x, y, z);
        System.out.println("============================================");
        System.out.println("welcome "+username);
        float vol=(x*y*z);
        System.out.println("volume = "+vol);
    }
    
}
 
public class assignment10 {
 
    public static void main(String[] args) {
        // TODO code application logic here
        second obj=new second();
        Scanner scan=new Scanner(System.in);
        System.out.println("enter number : ");
        float a=scan.nextInt();
         System.out.println("enter number : ");
         float b = scan.nextInt();
          System.out.println("enter number : ");
          float c=scan.nextInt();         
          
        obj.Calculate(a, b, c);
    }
    
}

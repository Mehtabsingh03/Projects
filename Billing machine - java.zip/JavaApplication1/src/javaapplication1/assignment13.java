
package javaapplication1;

import java.util.ArrayList;

 
public class assignment13 {

    
    public static void main(String[] args){ 
            ArrayList al = new ArrayList();
            al.add(12);
            al.add(132);
            al.add(1223424);
            al.add(122342);
            al.add(122222);
              
            Object a[]=al.toArray();
              
             System.out.println("average  = "+(sum(a)/5));
             al.add(34598);
             al.add(234234);
             Object two[]=al.toArray();
             System.out.println("average = "+((sum(two))/7));
             
             al.remove(0);
             al.remove(4);
             al.remove(3);
             Object three[]=al.toArray();
             System.out.println("average  ="+((sum(three))/4));
            
          
             
    }  
    public static int sum(Object nn[]){
        Object a[] = nn;
        int m=0;
      for(Object c : a)
            {   String s =c.toString();
                int r  = Integer.parseInt(s);
               
                m+=r;
            }       
        return m ;
    }
        
}
   
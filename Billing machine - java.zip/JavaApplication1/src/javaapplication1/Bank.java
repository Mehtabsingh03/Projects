 
package javaapplication1;
class account {
    int balance =1000;
   synchronized  void change(String name,int a){
         System.out.println(name+" balaance = "+balance);
        if(a<0){
            System.out.println(name+" withdraw "+a+"so balane = "+(balance+a));
        }
            else if (a>0){
                    System.out.println(name+" deposit "+a+"so balance = "+(balance+a));
                    }
        
    }
}

class buddy extends Thread
{
    account mj;
    String name ;
    int a;
     public buddy(account obj,String some ,int r)
     { name=some;
     mj=obj;
     a=r;
    }
    @Override
    public void run(){
        
        System.out.println(name+" enters");
        mj.change(name, a);
        System.out.println(name+"exits");
        
        
    }
}

 
public class Bank {

    
    public static void main(String[] args)
    {
        account frr=new account();
        buddy obj=new buddy(frr,"winchester",4000);
        buddy obj2=new buddy(frr,"sam",-500);
        buddy obj3=new buddy(frr,"dean",-900);
    
        obj.start();
        obj2.start();
        obj3.start();
         
    }
    
}

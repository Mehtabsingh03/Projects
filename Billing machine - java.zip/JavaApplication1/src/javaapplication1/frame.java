 
package javaapplication1;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.*;

class myframe extends JFrame
{
    
    JLabel l1;
    JTextField t1;
    JComboBox c1;
    JRadioButton r1;
    JRadioButton r2;
    JCheckBox ch1;
    JCheckBox ch2;
    JButton done;
    ButtonGroup grp;
    JTextArea ta;
   public myframe()
           {
               setDefaultCloseOperation(DISPOSE_ON_CLOSE);
               setTitle("my first");
               setSize(500,250);
               setLayout(new GridLayout(8,0));
               l1 = new JLabel("welcome");
               t1 = new JTextField();
               c1 = new JComboBox();
               r1 = new JRadioButton("male");
               r2 = new JRadioButton("female");
               ch1 = new JCheckBox("reading");
               ch2 = new JCheckBox("singing");
               done = new JButton("done");
               grp = new ButtonGroup();
               ta = new  JTextArea("any suggestions"); 
               
               add(l1);
               add(t1);
               c1.addItem("india");
               c1.addItem("canada");
               c1.addItem("america"); 
               c1.addItem("newzealand");
               add(c1);
               grp.add(r1);
               grp.add(r2);
               add(r1);
               add(r2);
               add(ch1);
               add(ch2);
               add(ta);
               add(done);
               
               
               
               
               
               
           }
}

 
public class frame {

   
    public static void main(String[] args) {
        // TODO code application logic here
        myframe f1 =new myframe();
        f1.setVisible(true);
    }
    
}

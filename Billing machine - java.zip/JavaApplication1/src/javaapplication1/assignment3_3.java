/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import java.util.Scanner;
/**c
 *
 * @author MEHTAB
 */
public class assignment3_3{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.print("\nenter your weight in kg -> ");
        float b = scan.nextFloat();
        System.out.print("\nenter your height in feet -> ");
        float hf = scan.nextFloat();
        float h = (float) (hf/3.28);
        float bmi = (b/(h*h));
        
        if (bmi <18.5)
        {
            System.out.println("you are under weight"); 
        }
        else if ((bmi<=25) && (bmi>=18.5))
                {
                    System.out.println("you have normal weight");
                }
        else if((bmi<=30) && (bmi>=25))
        {
            System.out.println("you are over weight");
            
        }
        else if (bmi>30)
        {
            System.out.println("you are obess");
        }
        
        
    }
    
}

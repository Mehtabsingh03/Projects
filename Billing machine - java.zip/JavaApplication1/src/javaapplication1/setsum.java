 
package javaapplication1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

 
public class setsum {

 
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("================= set ==================");
        HashSet n1=new HashSet();
        n1.add(55);
        n1.add(54);
        //n1.add(59.55f); same data type
        n1.add(50);
        n1.add(58);
        int sum =0;
        for(Object b:n1){
            System.out.println(b);
            String st=b.toString();
            int x=Integer.parseInt(st);
            sum+=x;
        }
        System.out.println("sum ="+sum);
        System.out.println("");
        
        System.out.println("================== treeset ================");
        
        TreeSet<Integer> t1= new TreeSet();
        t1.add(343);
        t1.add(347);
        t1.add(346);
        t1.add(343);//no duplicate
        t1.add(342);
         int lum =0;
        for(int x:t1){
            System.out.println(x);
            //String st=b.toString();
            //int x=Integer.parseInt(st);
            lum+=x;
        }
        System.out.println("sum ="+lum);
        System.out.println("");
        
        
        
        
        
        System.out.println("================== Aray list ======================");
           ArrayList<Integer> t11= new ArrayList();
        t11.add(343);
        t11.add(347);
        t11.add(346);
        t11.add(343);//no duplicate
        t11.add(342);
         int lumn =0;
      
        
        System.out.println("");
        
        Iterator it;
        it=t11.iterator();
        while (it.hasNext())
        {
          Object x= it.next();
          String st=x.toString();
            int r=Integer.parseInt(st);
            lumn+=r;
          
            System.out.println(x);
        }
        System.out.println("sum ="+lumn);
        
        
        
    }
    
}

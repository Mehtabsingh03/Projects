 
package javaapplication1;

 

class ithread extends Thread
 {
    @Override
    public void run(){
        for(int i=1;i<=50000;i++)
        {
            System.out.println("first "+i);
            if(i==10000)
            {
                try {
                    this.sleep(2);
                } catch (InterruptedException ex) { 
                 
                }
            }
        }
    } 
 }
class ithread2 implements Runnable
{

    @Override
    public void run() {
         for(int i=1;i<=50000;i++)
        {
            System.out.println("second "+i);
                        if(i==20000){
                Thread.currentThread().stop();
            }
        }
    }
    
}
class ithread3 extends Thread
{
  @Override
  public void run(){
     for(int i=1;i<=50000;i++)
        {
            System.out.println("third "+i);
            if(i==30000){
              this.yield(); 
            }

        }
}  
}
public class assignment11 {

 
    public static void main(String[] args) { 
        ithread obj=new ithread();
        ithread2 t1=new ithread2();
        Thread obj2=new Thread(t1);
        ithread3 obj3=new ithread3();
        
        obj.setPriority(Thread.MAX_PRIORITY);
        obj2.setPriority(5);
        obj3.setPriority(1);
        obj.start();
        obj2.start();
        obj3.start();
    }
    
}

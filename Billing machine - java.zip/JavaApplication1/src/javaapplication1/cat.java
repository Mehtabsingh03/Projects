/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author MEHTAB
 */
public class cat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        
        try
        {
            System.out.println("enter number : ");
        int a=scan.nextInt();
        System.out.println("enter number : ");
        int b=scan.nextInt();
        int c=a/b;
        System.out.println("answer : "+c);
            
        }
        catch(ArithmeticException e){
            System.out.println("denominator can't be zero"+e.getMessage());
         }      
        catch(Exception e)
        {
            System.out.println("Error : "+e.getMessage());  
        }
        System.out.println("============ thank you ======================== ");
        
    }
    
}

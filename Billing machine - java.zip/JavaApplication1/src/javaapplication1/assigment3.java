/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author MEHTAB
 */
public class assigment3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         int a;
        String f,l ;
        String gender,v;
        Scanner scan= new Scanner(System.in);
        Scanner scan2= new Scanner(System.in);
        System.out.print("\n please enter your first name   -->");
        f =scan.nextLine();
        System.out.print("\n please enter your last name   -->");
        l = scan.nextLine();
        scan.nextLine();
        System.out.print("\n please enter your age   -->");
        //scan.nextLine();//when change data type either changer scanner 
        //or rum empty scanner
        a = scan2.nextInt();//more sucesss
       
       
        if (a>20)
             
            {
                System.out.print("\n please enter your gender male/female   -->");
                gender =scan.nextLine();
                if (gender.equals("female"))
                {
                    System.out.print("\n Are you married ? reply with yes/no  -->");
                    v=scan.nextLine();
                    if (v.equals("yes"))
                    {
                        System.out.print("\n Name   -->  Mrs. "+f+" "+l);
                    }
                    else if(v.equals("no"))
                    {
                        System.out.print("\n Name   -->  Ms. "+f+" "+l);
                    }
                    

                }
                else if(gender.equals("male"))
                {
                    System.out.print("\n Name   --> Mr. "+f+" "+l);
                }
              

            }
      else 
       {
            System.out.print("\n Name   -->"+f+"  "+l);
      }


    }
    
}

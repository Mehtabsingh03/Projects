/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author MEHTAB
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        String a ;
        System.out.println("========= string ============");
        System.out.print("\n enter the name of college ->");
        a = scan.nextLine();
        System.out.println("name ->"+a);
        System.out.println("capital name ->"+a.toUpperCase());
        int b = a.length();    
        System.out.println("last word of college is ->"+a.charAt(b-1));
        System.out.println("the   replaced  name    ->"+a.replace("a","A"));
        System.out.print("enter  your     name    ->");
        String d= scan.nextLine();
        System.out.println(d+" studies in "+a);
        
        System.out.println("");
        System.out.println("=========== String buffer ============");
        
         System.out.print("\n enter your name ->");
        String x =scan.nextLine();
        StringBuffer v = new StringBuffer(x);     
        System.out.println("in buffer = "+v);
        System.out.println(v.insert(0, "welcome "));
        v.delete(0, 7);
        System.out.println(v.append(" is learning Core Java"));
        System.out.println(v.insert(v.indexOf("Java") ,"- "));
        System.out.println("in lowercase ->"+v.toString().toLowerCase());
        System.out.println("last letter is "+v.charAt(v.length()-1));
      
    }
    
}


package javaapplication1;

import java.util.Scanner;

class employee{
    String name;
    public employee(){
    Scanner scan=new Scanner(System.in);
    System.out.println("enter name : ");
     name = scan.nextLine();
    }
}
class department extends employee {
    String depart;
    public department (){
         Scanner scan=new Scanner(System.in);
        System.out.println("enter department : ");
        depart =scan.nextLine();
    }
}
interface bonus1
{
   int b1=500;
}
interface bonus2
{
    float b2 =(float) 1/10;
}
class salary extends department implements bonus1,bonus2
{  float sal;
    public salary()
    {
       Scanner scan=new Scanner(System.in);
        System.out.println("enter salary : ");
        sal=scan.nextFloat();
       
    }
    void show(){
        System.out.println("employee : "+name);
        System.out.println("department : "+depart);
       
        float total = (sal+b1+(sal*b2));
        System.out.println("total salary = "+total);
    }
    
}

 
public class assignment10_2 {
 
    public static void main(String[] args) {
        // TODO code application logic here
        salary obj=new salary();
        obj.show();
    }
    
}

 
package javaapplication1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

 
public class set {
 
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("================== set ==============================");
        HashSet n1=new HashSet();
        n1.add("mannu");
        n1.add(5);
        n1.add(65.33f);
        n1.add(2);
        n1.add('e');
        n1.add('e');//no duplicate
        System.out.println("n1 = "+n1);
        n1.remove(2);//only value 
        n1.remove(3);//no three no remove
        System.out.println("new = "+n1);
        //System.out.println(n1.get(2)); don't work because no sequence
        System.out.println("size = "+n1.size());
        System.out.println("");
        
        //work both ways
       // Object[] trr =n1.toArray();
        for(Object r : n1){
            System.out.println(r);
        }
        System.out.println("");
        
        
        
        
        System.out.println("==================== Sorted set =====================");
        TreeSet t1=new TreeSet();
        t1.add("love");
        t1.add("is");
        t1.add("blind");
        t1.add("simran");
        t1.add("44");
        t1.add("love");//no duplicate
        System.out.println("t1 = "+t1);
        t1.remove("simran");
        //t1.remove(2);//as every element in inverted so no chance of place value
        t1.remove("2");//no response because no element name 2
        System.out.println("new  = "+t1);
        System.out.println("size == "+t1.size());
       // System.out.println("element at 2"+t1.get("44"));
       //not working because it has its own order not the place we choose 
        System.out.println("");
        
        Object[] arr=t1.toArray();
        for(int i=0 ;i<arr.length ;i++)
        {
            System.out.println(arr[i]);
        }
        System.out.println("");
        
       // for(Object t : t1)
         // {
           // System.out.println(t1);//show 4 times array
        //}
        System.out.println("");
        
        
        
        System.out.println("====================== Array List ===================");
        ArrayList a1=new ArrayList();
        a1.add(1);
        a1.add("devakshi");
        a1.add(33.223f);
        a1.add(11);
        a1.add('d');
        a1.add('d');//allow duplicate 
        System.out.println("arraylist = "+a1);
        a1.remove("devakshi");
        a1.remove(1);//place value so 33.223
        Integer x=1;//for object first make object
        a1.remove(x);//element 1
        System.out.println("new  = "+a1);
        System.out.println(a1.get(0));
        //System.out.println(a1.get('d'));  only works for index
        System.out.println("size "+a1.size());
        System.out.println("");
        //work both ways 
        //Object yrr[]=a1.toArray();
        for(Object r : a1){
            System.out.println(r);
        }
        System.out.println("");
        
        
        
        
        
        System.out.println("================== map / table  =======================");
        Hashtable h1 =new Hashtable();
        h1.put("mehtab",33);
        h1.put("iqbal",0);
        h1.put("kiran",100);
        h1.put("teg", 77);
       // h1.add("teg",00); neveer same key
        System.out.println("table "+h1);
        h1.remove(0);//only work for key value 
        h1.remove("teg");
        System.out.println("new "+h1);
        
        //Object []mm=h1 cannot convert into array beacause of 2 values 
       // Object[] mm=h1.keySet(); not even key
        Set nn = h1.keySet();//only set
        Set mm=h1.entrySet();//both values
        for (Object y: mm){
            System.out.println(y);
        }
        
        
        
        System.out.println("============= stack ====================");
        Stack s1 =new Stack();
        s1.push("hwllo");
        s1.push(mm);
        System.out.println("stack = "+s1);
        s1.push(99);
        System.out.println(s1.peek());
        System.out.println("delete "+s1.pop());
        Object []p=s1.toArray();
        System.out.println("");
        for(Object r : p)
        {
            System.out.println(r);
        }
        System.out.println("");
                  
        
        
        
        
        System.out.println("=================== queue=========================");
        LinkedList ll=new LinkedList();
        ll.add("gh");
        ll.add("slf");
        ll.add(33);
        System.out.println(ll);
        System.out.println(ll.poll());//delete the oldest
        System.out.println(ll.peek());
        
        
    }
    
}

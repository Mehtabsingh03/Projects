/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author MEHTAB
 */
public class assignment5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
         Scanner scan2=new Scanner(System.in);
        //datatype array name and syntax=new datatype[size]
        //direct value int a[]={1,2,3};
        int weight[][] =new int[4][4];
        for(int c=0;c<weight.length;c++)//use a.length always never c or any var
        {
           
                System.out.println("enter wieght = ");
                int r=scan.nextInt();
                weight[c][0] = r;
                System.out.println("enter height = ");
                int f=scan2.nextInt();
                weight[c][1]= f;
                
                
            
        }
        int count =0;
        int mount=0;int tount=0;
        for(int c=0;c<weight.length;c++)
         {
        System.out.println("person "+ (c+1) +"\t"+(weight[c][0])+"  "+(weight[c][1]));
        if (weight[c][0]<60)
        {
        count++;
         }
        if (weight[c][1]>5.5)
        {
          mount++;  
        }
        if ((weight[c][0]<60) && (weight[c][1]>5.5) ){
          tount++;  
        }
        }
        System.out.println("number of person with less than 60 kg  -> "+count);
        System.out.println("number of person with more than 5.5 height -> "+mount);
        System.out.println("number of person with both   -->  "+tount);
    }
         
}
    

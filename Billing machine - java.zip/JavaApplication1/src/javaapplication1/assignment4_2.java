/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author MEHTAB
 */
public class assignment4_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan= new Scanner(System.in);
        for (int i=0 ;i<5 ;i++ )
        {
            System.out.print("\nenter the divident ->");
            int a= scan.nextInt();
            System.out.print("\nenter the  divisor ->");
            int b= scan.nextInt();
            if(b==0)
                    {System.out.print("\nwrong divisor , enter again ->");
                    b=scan.nextInt();
                     System.out.println("quotient  = "+a/b);
                     System.out.println("remainder = "+a%b);
                    continue ;}
            System.out.println("quotient  = "+a/b);
            System.out.println("remainder = "+a%b);
             
           
        }
    }
    
}

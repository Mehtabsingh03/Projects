/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author MEHTAB
 */
public class pattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("========== first pattern ===========");
        System.out.print("\n enter the number for the patten to work till -> ");
        int a = scan.nextInt();
        for (int i=1 ; i<=a ; i++)
        {
            for (int p=1 ; p<=i; p++)
            {
                System.out.print(p);
             
            }
            System.out.println("");
        }
        
        System.out.println("");
        System.out.println("============ second pattern ============");
        System.out.print("\n enter the number for the patten to work till -> ");
        int b = scan.nextInt();
        for (int i=b ; i>=1 ; i--)
        {
            for (int p=1 ; p<=i; p++)
            {
                System.out.print(i);
             
            }
            System.out.println("");
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;
import test.great;
/**
 *
 * @author MEHTAB
 */
public class assignment9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        System.out.println("enter number : ");
        int a=scan.nextInt();
         System.out.println("enter number : ");
         int b = scan.nextInt();
          System.out.println("enter number : ");
          int c=scan.nextInt();
          great.great(a,b,c);          
          
    }
    
}

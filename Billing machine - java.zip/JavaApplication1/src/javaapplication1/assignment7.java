/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import java.util.Scanner;


class a7_1
{
        int a;
        int b;
        int c;
        
    
  public  a7_1 ()
            {Scanner scan=new Scanner(System.in);
                System.out.print("\nenter a number = ");
                a =scan.nextInt();
                System.out.print("\nenter a number = "); 
                b=scan.nextInt();
                System.out.print("\nenter a number = "); 
                c =scan.nextInt();
            }
    void average()
    {
        float t= ((float) a+(float) b+(float) c)/3 ;
        System.out.println("avarage "+t);
    }
    void greatest()
    {
        if (a>b)
        {
            if (a>c)
            {
                System.out.println("value at a is greatest = "+a);
            }
            
        }
        else if (b>c)
        {
            System.out.println("value at b is greatest = "+b);
            
        }
        else 
        {
            System.out.println("value at c is greatest = "+c);
        }
    }
    
}

/**
 *
 * @author MEHTAB
 */
public class assignment7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        a7_1 obj=new a7_1();
        obj.average();
        obj.greatest();
    }
    
}

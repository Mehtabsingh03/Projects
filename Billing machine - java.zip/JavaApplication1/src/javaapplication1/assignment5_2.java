/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import java.lang.Math;
import java.util.Scanner;

/**
 *
 * @author MEHTAB
 */
public class assignment5_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan=new Scanner(System.in);
        int a[]=new int[10];
        for (int i=0;i<10 ;i++)
        {
          int x= (int) Math.round(Math.random()*100);
          a[i]=x;
        }
        for(int r : a)
        {
            System.out.println(+r+" "); //not use a[r] 
                                         //r will have value of a[i
        }
        
      
        System.out.print("\nenter the number you to find count of -> ");
        int m=scan.nextInt();
        
        int count=0;
        for (int t=0;t<10;t++)
        {
         if (m==a[t])
             count++;
        }
        System.out.println("count = "+count);
        
    }
    
}

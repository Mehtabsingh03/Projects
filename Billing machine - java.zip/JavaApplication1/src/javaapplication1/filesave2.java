/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author MEHTAB
 */
public class filesave2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("===================== char save =====================");
        int b;
        int force;
        char[] m={'\n','h','e','l','l','o'};
        String str = "\neloo there mate ";
        FileReader mns=null;
        FileReader ins=null;
        FileWriter outs=null;
        try{
            ins = new FileReader("D:/New folder/first.txt");
            outs = new FileWriter("D:/New folder/second.txt");
            mns = new FileReader("D:/New folder/second.txt");
            
            while((b=ins.read()) !=-1)
            {
                System.out.print((char)b);
                outs.write(b);
            }
            outs.write(m);
            outs.write(str);
            
             
            while((force=mns.read()) !=-1)
            {
                 
                System.out.println((char)force);
                
            }
            //System.out.println(mns.read(m));
            
            ins.close();
            outs.close();
            mns.close();
            System.out.println("file saved");
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        System.out.println("");
        
        
        
    }
    
}

 
package javaapplication1;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;



class mini extends JFrame implements ActionListener{
    JButton b1 ,b2 ,b3;
    JTextField t1,t2,t3;
    JLabel l1,l2,l3,l4,l5;
    public mini(){
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(400,400);
        setTitle("mini calculater");
        setLayout(null);
    b1 = new JButton("Average");
     b2 = new JButton("Volume");
      b3 = new JButton("Greatest");
      
      
      t1= new JTextField();
      t2= new JTextField();
      t3= new JTextField();
      
      
      l1 = new JLabel("Enter First number");
      l2 = new JLabel("Enter Second number");
      l3 = new JLabel("Enter Third number");
      l4 = new JLabel("Answer is");
      l5 = new JLabel();
      
      add(b1);
      add(b2);
      add(b3);
      add(t1);
      add(t3);
      add(t2);
      add(l1);
      add(l2);
      add(l3);
      add(l4);
      add(l5);
      l1.setBounds(25,10,125,40);
      t1.setBounds(225,10,125,40);
      l2.setBounds(25,60,125,40);
      t2.setBounds(225,60,125,40);
      l3.setBounds(25,110,125,40);
      t3.setBounds(225,110,125,40);
      b1.setBounds(225,160,125,40);
      b2.setBounds(225,210,125,40);
      b3.setBounds(225,260,125,40);
      l4.setBounds(25,310,125,40);
      l5.setBounds(225,360,125,40);
      b1.addActionListener(this);
      b2.addActionListener(this);
      b3.addActionListener(this);
    
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Double x = Double.parseDouble(l1.getText());
        Double y = Double.parseDouble(l2.getText());
        Double z = Double.parseDouble(l3.getText());
        if(e.getSource()==b1)
        {
           Double q = (x+y+z)/3;
           q.toString();
           l5.setText(q);
        }
    }
       
}


public class Assignment17 {

   
    public static void main(String[] args) {
       mini obj = new mini();
       obj.setVisible(true);
    }
    
}

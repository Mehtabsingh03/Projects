 
package javaapplication1;

import java.util.Scanner;

class error1 extends Exception
{
    public error1(){
        super("too less marks show some kindness");
    }
}
class error2 extends Exception
{
    public error2(){
        super("too much marks ");
    }
}
 
public class assignment12 {

 
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan =new Scanner(System.in);
        
       
        try {
         System.out.print("enter math marks");
         int a=scan.nextInt();
         System.out.print("enter english marks");
        int b=scan.nextInt();
         System.out.print("enter science marks");
        int c=scan.nextInt();
        if ((a<0) || (b<0) || (c<0))
        {
            throw new error1();
        }
        else if((a>100)||(b>100)||(c>100))
        {
            throw new error2();
        }
        else{
            System.out.println(((float)a+(float)b+(float)c/3));
        }
        
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
}

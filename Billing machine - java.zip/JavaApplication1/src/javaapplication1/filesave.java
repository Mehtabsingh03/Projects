 
package javaapplication1;
 
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class filesave {

  
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        
        System.out.println("============= byte save ====================");
        try {
            // TODO code application logic here
            byte a[]={'s','o','o','\n'};
            String st="much fun";
            byte b[] =st.getBytes();//[] is essential in byte
            int d=99+23;
            String ff=String.valueOf(d);
            byte c[]=ff.getBytes();
            
            
            FileOutputStream sver=new FileOutputStream("D:/New folder/first.txt");
            sver.write(a);
            sver.write(b);
            sver.write(c);
            sver.close();
            System.out.println("saved ");
            System.out.println("");
            System.out.println("===========================================");
        } catch (Exception ex) {
             System.out.println(ex.getMessage());
        } 
        
        
        
        
        
        
        int b;
        try {
        FileInputStream vw=new FileInputStream("D:/New folder/first.txt");
         while((b=(vw.read())) != -1)
         {
             System.out.println((char)b);
         }
         vw.close();
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        
        
         
        
        
        
        
        System.out.println("===================== char save =====================");
        int force;
        char[] m={'\n','h','e','l','l','o'};
        String str = "\neloo there mate ";
        FileReader mns=null;
        FileReader ins=null;
        FileWriter outs=null;
        try{
            ins = new FileReader("D:/New folder/first.txt");
            outs = new FileWriter("D:/New folder/second.txt");
            mns = new FileReader("D:/New folder/second.txt");
            
            while((b=ins.read()) !=-1)
            {
                System.out.print((char)b);
                outs.write(b);
            }
            outs.write(m);
            outs.write(str);
            
             
            while((force=mns.read()) !=-1)
            {
                 
                System.out.println((char)force);
                
            }
            //System.out.println(mns.read(m));
            
            ins.close();
            outs.close();
            mns.close();
            System.out.println("file saved");
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        System.out.println("");
        
        
        
        
        System.out.println("===================== data save ===================");
        try{
        File one =new File("D:/New folder/third.txt");
        FileOutputStream two = new FileOutputStream(one);
        DataOutputStream three = new DataOutputStream(two);
        three.write(88);
        three.writeFloat(93.23f);
        three.writeChar('c');
        three.writeChars("well done");
        
        FileInputStream four = new FileInputStream(one);
        DataInputStream five = new DataInputStream(four);
            System.out.println(five.read());
            System.out.println(five.readFloat());
            System.out.println(five.readChar());
            System.out.println(five.readLine());
        
        five.close();
        three.close();
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        System.out.println("");
        
        
        
        
    }
    
}

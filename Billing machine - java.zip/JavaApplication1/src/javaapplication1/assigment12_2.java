 
package javaapplication1;

import java.util.Scanner;

class erir extends Exception {
    public erir(){
        super("Number to small ... better luck next time ");
        
    }
    
}


class errr extends Exception
{
    public errr(){
        super("Number too biggg ...  better luck next time ");
    }
}

 
public class assigment12_2 {

    
    public static void main(String[] args) {
        try{
        Scanner scan = new Scanner(System.in);
       int a = (int) (10*(Math.random()));
        
        System.out.println("Guess the number  :");
        int guess = scan.nextInt();
        if(guess == a){
            System.out.println("Congrats ! you guessed it right");  
        }
        else if (guess>a){
           throw new  errr(); 
        }
        else {
            throw new erir();
        }
        }
        catch(Exception e){ 
            System.out.println(e.getMessage());
        }
         
         
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;
class one
{
        int a;int b;int c;int d;int f;
        public one()
        {
            Scanner scan=new Scanner(System.in);
            
                System.out.print("\nenter first number = ");
                a =scan.nextInt();
                System.out.print("\nenter second number = "); 
                b=scan.nextInt();
                System.out.print("\nenter third number = "); 
                c =scan.nextInt();
                System.out.print("\nenter fourth number = "); 
                d=scan.nextInt();
                System.out.print("\nenter fifth number = "); 
                f =scan.nextInt();
              
                
        }
        void greatest(){
            System.out.println("==== greatest=======");
             if (a>b)
        {
            if (a>c)
            {
                System.out.println("value at a is greatest from first 3  =  "+a);
            }
            
        }
        else if (b>c)
        {
            System.out.println("value at b is greatest from first 3 =  "+b);
            
        }
        else 
        {
            System.out.println("value at c is greatest from first 3  =  "+c);
        }
            
        }
    }
    class two extends one
    {
        
        void average(){
            float r=  (( (float) a+ (float)b+ (float)c+ (float)d+ (float)f)/5);
            System.out.println("the average is = "+r);
    }
        
        
    }
    

/**
 *
 * @author MEHTAB
 */
public class assignment8_2 {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        two ojj=new two();
        ojj.average();
        ojj.greatest();
        
    }
    
}

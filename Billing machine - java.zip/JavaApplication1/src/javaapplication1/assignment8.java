
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

class a8_1
{
    float a;
    float b;
    public a8_1()
            {
               Scanner scan=new Scanner(System.in);
                System.out.print("\nenter the length in m = ");
                a =scan.nextFloat();
                System.out.print("\nenter the width in m = "); 
                b=scan.nextFloat(); 
            }
     void area()
     {
         System.out.println("the area of rectangle is "+(a*b)+"m");
     }
}

class a8_2 extends a8_1
{
    void pm()
    {
        System.out.println("the perimeter of rectangle is "+(2*(a+b))+"m");
    }
}

class a8_average
{
    float a;
    float b;
    public a8_average()
    {
        Scanner scan=new Scanner(System.in);
                System.out.print("\nenter a number = ");
                a =scan.nextFloat();
                System.out.print("\nenter a number = "); 
                b=scan.nextFloat();
    }
    void display()
    {
        float i =  (((a+b)/2));
        System.out.println("the average of first 2 numbers = "+i);
    }
          
}
class a8_average_2 extends a8_average
{
    float c;
    public a8_average_2()
            {
                Scanner scan=new Scanner(System.in);
              System.out.print("\nenter a number = ");
               c =scan.nextFloat();  
            }
    void display_2()
    {
        float o = ((a+b+c)/2);
     System.out.println("the average of all 3 numbers = "+o);   
    }
}
/**
 *
 * @author MEHTAB
 */
public class assignment8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("========= rectangle======");
        a8_2 oj = new a8_2();
        oj.area();
        oj.pm();
        System.out.println("======== average========");
        a8_average_2 sum=new a8_average_2();
        sum.display();
        sum.display_2();
       
        
        
        
    }
    
}

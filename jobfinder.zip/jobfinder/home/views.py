from django.shortcuts import render, redirect
from django.views import View
from .models import job



class DeletePageView(View):
    def post(self, request, job_id):
        try:
            jobdata1 = job.objects.get(id=job_id)
            jobdata1.delete()
        except job.DoesNotExist:
            pass
        jobdata = job.objects.all()
        return render(request, 'index.html', {'jobdata': jobdata})

        
        
class HomePageView(View):
    def get(self, request):
        # Query to fetch all jobs
        jobdata = job.objects.all()  
        return render(request, 'index.html', {'jobdata': jobdata})
    
class addPageView(View):
    def get(self, request):
        return render(request, 'add.html')

    def post(self, request):
        # Extract form data
        company_name = request.POST.get('companyName')
        job_title = request.POST.get('jobTitle')
        salary = request.POST.get('salary')
        employer_name = request.POST.get('employerName')
        employer_email = request.POST.get('email')
        employer_phone = request.POST.get('phone')

        # Save data to the database
        job_instance = job(
            company_name=company_name,
            job_title=job_title,
            salary=salary,
            employer_name=employer_name,
            employer_email=employer_email,
            employer_phone=employer_phone
        )
        job_instance.save()

        # Redirect to another page or render a success message
        return redirect('/')
    


from django.db import models

# Create your models here.
class job(models.Model):
    company_name = models.CharField(max_length=200)
    job_title = models.CharField(max_length=200)
    salary = models.CharField(max_length=100)
    employer_name = models.CharField(max_length=200)
    employer_email = models.EmailField(max_length=200)
    employer_phone = models.CharField(max_length=12)
from django.contrib import admin
from .models import job

# Register your models here.
@admin.register(job)  # Register the actual model class, not a string
class JobAdmin(admin.ModelAdmin):
    list_display = ['id', 'company_name', 'job_title', 'salary', 'employer_name', 'employer_email', 'employer_phone']
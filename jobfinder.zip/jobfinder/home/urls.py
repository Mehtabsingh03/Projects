from django.urls import path
from .views import   HomePageView,addPageView,DeletePageView

urlpatterns = [
    path('', HomePageView.as_view(), name="home"),
    path('add/', addPageView.as_view(), name="add"),
    path('delete/<int:job_id>/', DeletePageView.as_view(), name='delete'),
]
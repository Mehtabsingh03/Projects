from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Treeview
from details import *
import pymysql


class Pass:
    def __init__(self,parent,uname):
        self.uname = uname
        self.bpage = Toplevel(parent)
        self.header = Label(self.bpage,text='Change Password',font=("Cooper Black",50,'bold','underline'),anchor='center')
        self.l1 = Label(self.bpage,text='current password',font=("Bahnschrift SemiBold SemiConden",14))
        self.l2 = Label(self.bpage,text='New Password',font=("Bahnschrift SemiBold SemiConden",14))
        self.l3 = Label(self.bpage,text='Confim Password',font=("Bahnschrift SemiBold SemiConden",14))
        self.t1 = Entry(self.bpage,width=30,show="*")
        self.t2 = Entry(self.bpage,width=30,show="*")
        self.t3 = Entry(self.bpage,width=30,show="*")
        self.b1 = Button(self.bpage,text='Submit',command=self.Add)
        self.b2 = Button(self.bpage,text='Clear',command=self.clear)
        x1 = 10
        y1 = 140
        xd = 200
        self.header.place(x=0, y=0)

        self.l1.place(x=x1, y=y1)
        self.t1.place(x=x1 + xd, y=y1)
        y1 += 100

        self.l2.place(x=x1,y=y1)
        self.t2.place(x=x1 + xd, y=y1)

        y1 += 100

        self.l3.place(x=x1,y=y1)
        self.t3.place(x=x1 + xd, y=y1)
        y1 += 70
        self.b1.place(x=x1+100,y=y1)
        self.b2.place(x=x1+200,y=y1)
        self.bpage.mainloop()

    def Get_Connection(self):
        try:
            self.conn = pymysql.Connect(host=myhost,db=mydb,user=myuser,password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connnection Error ","Database Connection error"+str(e),parent= self.bpage)

    def Add(self):
        if self.t2.get() == self.t3.get():
            self.Get_Connection()
            try:
                qry = "update user set pass = %s   where username = %s and pass = %s"
                row_count = self.curr.execute(qry, (self.t2.get(),self.uname,self.t1.get()))
                self.conn.commit()
                if row_count == 1:
                    messagebox.showinfo("Success", "passsword changed successfully", parent=self.bpage)
                    self.clear()
                else:
                    messagebox.showwarning("Failure", "Password not Saved", parent=self.bpage)
            except Exception as e:
                messagebox.showerror("Query error","Query error :"+str(e),parent = self.bpage)

    def clear(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)
        self.t3.delete(0,END)


if __name__ == '__main__':
    d_window = Tk()
    Pass(d_window,"mehtab")
    d_window.mainloop()
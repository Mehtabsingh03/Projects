from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Treeview
from details import *
import pymysql


class Login:
    def __init__(self):
        self.bpage = Tk()
        w = self.bpage.winfo_screenwidth()
        h = self.bpage.winfo_screenheight()
        self.bpage.geometry("%dx%d+%d+%d" % (650,450,300,250))
        self.header = Label(self.bpage,text='Welcome  To Pollution Test',font=("Cooper Black",22,'bold','underline'),anchor='center')
        self.l1 = Label(self.bpage,text='Username',font=("Bahnschrift SemiBold SemiConden",14))
        self.l2 = Label(self.bpage,text='Password',font=("Bahnschrift SemiBold SemiConden",14))
        self.t1 = Entry(self.bpage,width=30)
        self.t2 = Entry(self.bpage,width=30,show="*")
        self.b1 = Button(self.bpage,text='Submit',command=self.Add)
        x1 = 10
        y1 = 140
        xd = 200
        self.header.place(x=0, y=0)

        self.l1.place(x=x1, y=y1)
        self.t1.place(x=x1 + xd, y=y1)
        y1 += 100

        self.l2.place(x=x1,y=y1)
        self.t2.place(x=x1 + xd, y=y1)
        y1 += 70
        self.b1.place(x=x1+100,y=y1)
        self.bpage.mainloop()

    def Get_Connection(self):
        try:
            self.conn = pymysql.Connect(host=myhost,db=mydb,user=myuser,password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connnection Error ","Database Connection error"+str(e),parent= self.bpage)

    def Add(self):
            self.Get_Connection()
            try:
                qry = "select * from user where username = %s and pass=%s"
                row_count = self.curr.execute(qry, (self.t1.get(), self.t2.get()))
                data = self.curr.fetchone()
                self.conn.commit()
                if data:
                    utype = data[5]
                    uname = data[1]
                    self.bpage.destroy()
                    from homepage import Homepage
                    Homepage(utype,uname)
                else:
                    messagebox.showwarning("Failure", "Check Username and Password again", parent=self.bpage)
            except Exception as e:
                messagebox.showerror("Query error","Query error :"+str(e),parent = self.bpage)


if __name__ == '__main__':
    Login()
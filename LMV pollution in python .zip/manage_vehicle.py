from sqlite3 import Date
from tkinter import *
from tkinter import Label
from tkcalendar import DateEntry
from tkinter.ttk import Combobox, Treeview
import pymysql
from tkinter import messagebox
from details import *

class  Vehicle:
    def __init__(self,page):
        self.vpage = Toplevel(page)
        self.vname = StringVar()

        self.header = Label(self.vpage, text="Manage vehicles" , font=("Cooper Black",50,'bold','underline'))
        self.l1 = Label(self.vpage, text = 'Vehicle No.',font=("Bahnschrift SemiBold SemiConden",14))
        self.l2 = Label(self.vpage,text = 'Customer Name',font=("Bahnschrift SemiBold SemiConden",14))
        self.l3 = Label(self.vpage,text= 'Customer Mobile',font=("Bahnschrift SemiBold SemiConden",14))
        self.l4 = Label(self.vpage,text= 'Date of Regn',font=("Bahnschrift SemiBold SemiConden",14))
        self.l5 = Label(self.vpage,text= 'Brand',font=("Bahnschrift SemiBold SemiConden",14))
        self.l6 = Label(self.vpage,text= 'Model',font=("Bahnschrift SemiBold SemiConden",14))

        self.t1 = Entry(self.vpage, width=24)
        self.t2 = Entry(self.vpage, width=24)
        self.t3 = Entry(self.vpage, width=24)
        self.t4 = DateEntry(self.vpage, width=22, background='blue', foreground='white', borderwidth=2,
                            date_pattern="y-mm-dd")
        self.v1 = StringVar()
        self.t5 = Combobox(self.vpage,textvariable=self.v1, width=22)
        self.v2 = StringVar()
        self.t6 = Combobox(self.vpage, textvariable=self.v2, width=22)
        self.Get_combo()
        self.t5.bind("<<ComboboxSelected>>", lambda e: self.Get_combo2())
        self.t6.set("Choose model")
        self.t6.config(values=["No model avialable"])

        self.b1 = Button(self.vpage,text='Fetch',command=self.fetch)
        self.b2 = Button(self.vpage, text='Search',command=self.Search)
        self.b3 = Button(self.vpage, text='Delete',command=self.delete)
        self.b4 = Button(self.vpage, text='Submit',command=self.add)
        self.b5 = Button(self.vpage, text='Update',command=self.update)
        self.b6 = Button(self.vpage, text='Clear',command=self.clear)


        self.table = Frame(self.vpage)
        self.mytable = Treeview(self.table,columns=('c1','c2','c3','c4','c5','c6'),height=20)
        self.mytable.heading('c1',text='Vehicle No.')
        self.mytable.heading('c2', text='Customer Name')
        self.mytable.heading('c3', text='Customer Mobile')
        self.mytable.heading('c4', text='Date of Regn')
        self.mytable.heading('c5', text='Brand')
        self.mytable.heading('c6', text='Model')
        self.mytable['show'] = 'headings'
        self.mytable.column('#1',width=100,anchor="center")
        self.mytable.column('#2', width=150, anchor="center")
        self.mytable.column('#3', width=150, anchor="center")
        self.mytable.column('#4', width=150, anchor="center")
        self.mytable.column('#5', width=150, anchor="center")
        self.mytable.column('#6', width=150, anchor="center")
        self.mytable.bind("<ButtonRelease-1>", lambda e: self.fetch_v())
        self.mytable.pack()


        x1 = 10
        y1 = 140
        xd = 200
        yd = 70
        yn = 40
        self.header.place(x=0,y=0)

        self.l1.place(x=x1,y=y1)
        self.t1.place(x=x1 + xd, y=y1)
        self.table.place(x=x1 +xd + xd + 50 ,y=y1)

        y1 += yn
        self.b1.place(x=x1 + xd,y=y1)

        y1=y1 + yn
        self.l2.place(x=x1,y=y1)
        self.t2.place(x=x1 + xd, y=y1)

        y1 += yn
        self.b2.place(x= x1+xd,y=y1)

        y1 += yn
        self.l3.place(x=x1,y=y1)
        self.t3.place(x=x1 + xd, y=y1)

        y1 += yd
        self.l4.place(x=x1,y=y1)
        self.t4.place(x=x1 + xd,y=y1)

        y1 += yd
        self.l5.place(x=x1,y=y1)
        self.t5.place(x=x1+xd,y=y1)

        y1 += yd
        self.l6.place(x=x1,y=y1)
        self.t6.place(x=x1+xd,y=y1)

        y1 += yd
        y1 += 40
        self.b3.place(x=x1,y=y1)
        self.b4.place(x=x1+xd,y=y1)
        self.b5.place(x=x1+xd+xd,y=y1)
        self.b6.place(x=x1+xd+xd+xd,y=y1)

        self.vpage.mainloop()

    def Get_Connection(self):
            try:
                self.conn = pymysql.connect(host=myhost, db=mydb, user=myuser, password=mypassword)
                self.curr = self.conn.cursor()
            except Exception as e:
                messagebox.showerror("Connection Error", "Database connection Error : " + str(e), parent=self.vpage)

    def Get_combo(self):
        self.Get_Connection()
        try:
            qry = "select * from brand"
            row_count = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.conn.commit()
            c_list=[]
            if data:
                self.t5.set("Choose Brand")
                for val in data:
                    c_list.append(val[0])
            else:
                self.t5.set("No Brands Available")
            self.t5.config(values=c_list)
        except Exception as e:
            messagebox.showerror("Query Error","Query Error :"+str(e),parent=self.vpage)

    def Get_combo2(self):
        self.Get_Connection()
        try:
            qry = "select model from model where brand = %s"
            row_count = self.curr.execute(qry,self.v1.get())
            data = self.curr.fetchall()
            self.conn.commit()
            c_list=[]
            if data:
                self.t6.set("Choose model")
                for val in data:
                    c_list.append(val[0])
                self.t6.config(values=c_list)
            else:
                self.t6.set("Choose model")
                self.t6.config(values=["No model Available"])

        except Exception as e:
            messagebox.showerror("Query Error","Query Error :"+str(e),parent=self.vpage)

    def add(self):
        if self.validation() == False:
            return
        self.Get_Connection()

        try:
            qry="insert into vehicle values(%s,%s,%s,%s,%s,%s)"
            row_count = self.curr.execute(qry,(self.t1.get(),self.t2.get(),self.t3.get(),self.t4.get_date(),self.v1.get(),self.v2.get()))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success","Vehicle submitted ,successfully",parent=self.vpage)
                self.clear()
            else:
                messagebox.showwarning("Failure","Vehicle not submitted",parent=self.vpage)

        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.vpage)

    def update(self):
        if self.validation() == False:
            return
        self.Get_Connection()

        try:
            qry="update vehicle set v_name = %s, c_name = %s , c_mobile = %s , date = %s , brand = %s , model = %s where v_name = %s"
            row_count = self.curr.execute(qry,(self.t1.get(),self.t2.get(),self.t3.get(),self.t4.get_date(),self.v1.get(),self.v2.get(),self.vname))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success","Vehicle updated ,successfully",parent=self.vpage)
                self.clear()
            else:
                messagebox.showwarning("Failure","Vehicle not updated",parent=self.vpage)

        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.vpage)


    def fetch_v(self):
        id = self.mytable.focus()
        items = self.mytable.item(id)
        myvalues = items['values']
        pk = myvalues[0]
        self.fetch(pk)


    def Search(self):

        self.Get_Connection()
        try:
            qry="select * from vehicle where v_name like %s"
            row_count = self.curr.execute(qry,(self.t1.get()+'%'))
            data = self.curr.fetchall()
            self.conn.commit()
            if data:
                self.mytable.delete(*self.mytable.get_children())
                for val in data:
                    self.mytable.insert("",END,values=val)
            else:
                messagebox.showwarning("Failure", "Vehicle not found", parent=self.vpage)
        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.vpage)

    def fetch(self,m = None):
        if m == None:
            m = self.t1.get()

        self.Get_Connection()
        try:
            qry="select * from vehicle where v_name = %s"
            row_count = self.curr.execute(qry,(m))
            data = self.curr.fetchone()
            self.conn.commit()
            if data:
                self.clear()
                self.t1.insert(0, data[0])
                self.t2.insert(0, data[1])
                self.t3.insert(0, data[2])
                self.t4.delete(0,END)
                self.t4.insert(0, data[3])
                self.v1.set(data[4])
                self.v2.set(data[5])
                self.vname = data[0]
            else:
                messagebox.showwarning("Failure", "Vehicle not found", parent=self.vpage)
        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.vpage)

    def delete(self):
        if self.validation() == False:
            return
        self.Get_Connection()

        try:
            qry="delete from vehicle where v_name = %s"
            row_count = self.curr.execute(qry,(self.t1.get()))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success","Vehicle deleted ,successfully",parent=self.vpage)
                self.clear()
            else:
                messagebox.showwarning("Failure","Vehicle not deleted",parent=self.vpage)

        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.vpage)

    def clear(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)
        self.t3.delete(0,END)
        self.t4.set_date(Date.today())
        self.Get_combo()
        self.Get_combo2()
        self.mytable.delete(*self.mytable.get_children())
        self.vname=''

    def validation(self):
        if (len(self.t1.get()) < 1):
            messagebox.showwarning("Validation Check", "Enter valid number \n atleats 1 charracters", parent=self.vpage)
            return False

        elif len(self.t2.get()) < 3 or not(self.t2.get().isalpha()):
            messagebox.showwarning("Validation Check", "Enter valid name \n atleats 3 charracters", parent=self.vpage)
            return False
        elif not(self.t3.get().isdigit()) or len(self.t3.get()) != 10:
            messagebox.showwarning("Validation Check", "Enter valid mobile number \n10 digits only", parent=self.vpage)
            return False
        elif (len(self.t4.get()) == ""):
            messagebox.showwarning("Input Error", "Please Select Date of regn ", parent=self.vpage)
            return False
        elif (self.v1.get() == "No Brands Available") or (self.v1.get() == "Choose Brand"):
            messagebox.showwarning("Input Error", "Please Select Brand ", parent=self.vpage)
            return False
        elif (self.v2.get() == "Choose model") or (self.v2.get() == "No model Available"):
            messagebox.showwarning("Input Error", "Please Select Model ", parent=self.vpage)
            return False
        return True

if __name__ == '__main__':
    d_window = Tk()
    Vehicle(d_window)
    d_window.mainloop()
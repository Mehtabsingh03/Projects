import datetime
import time
from sqlite3 import Date, Time
from tkinter import *
from tkinter import Label
from tkinter.filedialog import askopenfilename
from PIL import Image,ImageTk
from tkcalendar import DateEntry
from tkinter.ttk import Combobox, Treeview
import pymysql
from tkinter import messagebox
from details import *

class  Test:
    default_img = "default.jpg"
    def __init__(self,page):

        self.vpage = Toplevel(page)
        self.i_name = StringVar()
        self.test_no = StringVar()
        self.timme()
        self.get_id()
        self.header = Label(self.vpage, text="Manage Test" , font=("Cooper Black",50,'bold','underline'))
        self.l1 = Label(self.vpage, text = 'Test No.',font=("Bahnschrift SemiBold SemiConden",14))
        self.l2 = Label(self.vpage,text = 'vehicle Name',font=("Bahnschrift SemiBold SemiConden",14))
        self.l3 = Label(self.vpage,text= 'Time',font=("Bahnschrift SemiBold SemiConden",14))
        self.l4 = Label(self.vpage,text= 'Date',font=("Bahnschrift SemiBold SemiConden",14))
        self.l5 = Label(self.vpage,text= 'Center',font=("Bahnschrift SemiBold SemiConden",14))
        self.l6 = Label(self.vpage,text= 'Test Result',font=("Bahnschrift SemiBold SemiConden",14))
        self.t1 = Label(self.vpage, text=self.get_id(), font=("Bahnschrift SemiBold SemiConden", 14))
        self.t3 = Label(self.vpage, text=self.timme(), font=("Bahnschrift SemiBold SemiConden", 14))


        self.t2 = Entry(self.vpage, width=24)



        self.t4 = DateEntry(self.vpage, width=22, background='blue', foreground='white', borderwidth=2,
                            date_pattern="y-mm-dd")
        self.v1= StringVar()
        self.t5 = Combobox(self.vpage,textvariable=self.v1, width=22)
        self.v2 = StringVar()
        self.t6 = Combobox(self.vpage, textvariable=self.v2, width=22)
        self.Get_combo()
        self.t6.set('Choose Result')
        self.t6.config(values=["Pass","Fail"])




        self.b4 = Button(self.vpage, text='Clear',command=self.clear)
        self.b5 = Button(self.vpage, text='Submit',command=self.add)
        self.b6 = Button(self.vpage, text='Upload',command=self.get_image)


        self.l7 = Label(self.vpage, text='RPM (Max)', font=("Bahnschrift SemiBold SemiConden", 14))
        self.l8 = Label(self.vpage, text='RPM (Min)', font=("Bahnschrift SemiBold SemiConden", 14))
        self.l9 = Label(self.vpage, text='Km', font=("Bahnschrift SemiBold SemiConden", 14))
        self.l10 = Label(self.vpage, text='HSU%', font=("Bahnschrift SemiBold SemiConden", 14))
        self.l11 = Label(self.vpage, text='Temp', font=("Bahnschrift SemiBold SemiConden", 14))
        self.img = Label(self.vpage, borderwidth=2, relief='groove')
        self.t7 = Entry(self.vpage , width=24)
        self.t8 = Entry(self.vpage , width=24)
        self.t9= Entry(self.vpage , width=24)
        self.t10= Entry(self.vpage , width=24)
        self.t11 = Entry(self.vpage , width=24)
        x1 = 10
        y1 = 140
        xd = 200
        yd = 70
        yn = 40
        self.header.place(x=0,y=0)

        self.l1.place(x=x1,y=y1)
        self.t1.place(x=x1 + xd, y=y1)
        self.l7.place(x=x1+xd+xd +xd, y=y1)
        self.t7.place(x=x1+xd+xd+xd+xd, y=y1)


        y1=y1 + yd
        self.l2.place(x=x1,y=y1)
        self.t2.place(x=x1 + xd, y=y1)
        self.l8.place(x=x1 + xd + xd + xd, y=y1)
        self.t8.place(x=x1 + xd + xd + xd + xd, y=y1)

        y1 += yd
        self.l3.place(x=x1,y=y1)
        self.t3.place(x=x1 + xd, y=y1)
        self.l9.place(x=x1 + xd + xd + xd, y=y1)
        self.t9.place(x=x1 + xd + xd + xd + xd, y=y1)
        y1 += yd
        self.l4.place(x=x1,y=y1)
        self.t4.place(x=x1 + xd,y=y1)
        self.l10.place(x=x1 + xd + xd + xd, y=y1)
        self.t10.place(x=x1 + xd + xd + xd + xd, y=y1)
        y1 += yd
        self.l5.place(x=x1,y=y1)
        self.t5.place(x=x1+xd,y=y1)
        self.l11.place(x=x1 + xd + xd + xd, y=y1)
        self.t11.place(x=x1 + xd + xd + xd + xd, y=y1)
        y1 += yd
        self.l6.place(x=x1,y=y1)
        self.t6.place(x=x1+xd,y=y1)
        self.img.place(x=x1 + xd+xd+xd+xd, y=y1, width=150, height=150)

        y1 += yd
        y1 += 40

        self.b4.place(x=x1+xd,y=y1)
        self.b5.place(x=x1+xd+xd,y=y1)
        self.b6.place(x=x1+xd+xd+xd,y=y1)
        self.clear()
        self.vpage.mainloop()


    def Get_Connection(self):
            try:
                self.conn = pymysql.connect(host=myhost, db=mydb, user=myuser, password=mypassword)
                self.curr = self.conn.cursor()
            except Exception as e:
                messagebox.showerror("Connection Error", "Database connection Error : " + str(e), parent=self.vpage)

    def Get_combo(self):
        self.Get_Connection()
        try:
            qry = "select * from center"
            row_count = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.conn.commit()
            c_list=[]
            if data:
                self.t5.set("Choose center")
                for val in data:
                    c_list.append(val[0])
            else:
                self.t5.set("No center Available")
            self.t5.config(values=c_list)
        except Exception as e:
            messagebox.showerror("Query Error","Query Error :"+str(e),parent=self.vpage)



    def add(self):
        if self.validation() == False:
            return

        self.Get_Connection()
        if self.i_name==self.default_img:
            pass
        else:
            self.img1.save("images//"+self.i_name)
        self.v_nm = self.t2.get()
        try:
            qry="insert into test(v_name,time,date,center,test_result,rpm_max,rpm_min,km,hsu,temp,i_name) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            row_count = self.curr.execute(qry,(self.t2.get(),self.timme(),self.t4.get_date(),self.v1.get(),self.v2.get(),self.t7.get(),self.t8.get(),self.t9.get(),self.t10.get(),self.t11.get(),self.i_name))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success", "TEST submitted successfully",parent=self.vpage)
                self.clear()
                from final import Final

                Final(self.vpage,self.test_no,self.v_nm,self.i_name)

            else:
                messagebox.showwarning("Failure","TEST not submitted",parent=self.vpage)

        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.vpage)




    def clear(self):
        self.t2.delete(0,END)
        self.t4.set_date(Date.today())
        self.Get_combo()
        self.t6.set(value='Choose Result')
        self.t7.delete(0,END)
        self.t9.delete(0,END)
        self.t8.delete(0,END)
        self.t10.delete(0,END)
        self.t11.delete(0,END)
        self.t3.config(text=self.timme())
        self.get_id()
        self.t1.config(text=self.get_id())
        self.i_name = self.default_img
        self.img1 = Image.open("images//" + self.i_name)
        self.img1 = self.img1.resize((150, 150), Image.Resampling.LANCZOS)
        self.img2 = ImageTk.PhotoImage(self.img1)
        self.img.config(image=self.img2)

    def timme(self):
            self.list = str(time.asctime()).split(" ")
            return self.list[3]




    def get_id(self):
        self.Get_Connection()
        try:
            qry = "(select test_no from test)"
            row_count = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.conn.commit()
            if data:
                lit=[]
                m=''
                s = str(data[-1])
                for i in s:
                    if i.isalnum():
                        m+=i

                v1 = int(m)+1
                self.test_no = m

                return v1
            else:
                messagebox.showwarning("Failure", "Vehicle not found", parent=self.vpage)
        except Exception as e:
            messagebox.showerror("Query Error", "Query error :" + str(e), parent=self.vpage)


    def get_image(self):
        self.filename = askopenfilename(file = [ ("All pictures","*.png;*.jpg;*.jpeg")  ,("PNG Images ","*.png"),("JPG Images ","*.jpg")  ])

        if self.filename!="":
            self.img1 = Image.open(self.filename)
            self.img1 = self.img1.resize((150,150),Image.Resampling.LANCZOS)


            self.img2 = ImageTk.PhotoImage(self.img1)
            self.img.config(image=self.img2)

            path = self.filename.split("/")
            name = path[-1]
            import time
            uniqueness = str(int(time.time()))
            self.i_name = uniqueness+name

    def chech_v(self):
        self.Get_Connection()
        try:
            qry = "select v_name from vehicle"
            row_count = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.conn.commit()
            lit = []
            if data:
                for i in data:
                    d = str(i).split("'")
                    lit.append(d[1])
                for val in lit:
                    if str(val) == str(self.t2.get()):
                        return "Waheguru"
            else:
                messagebox.showwarning("Failure", "No Vehicles in the Found", parent=self.vpage)
        except Exception as e:
            messagebox.showerror("Query Error", "Query error :" + str(e), parent=self.vpage)

    def validation(self):
        if (len(self.t2.get()) < 3 or self.chech_v() != "Waheguru"):
            messagebox.showwarning("Validation Check", "Enter valid name \n Vehicle name not found in Database", parent=self.vpage)
            return False

        elif (len(self.t4.get()) == ""):
            messagebox.showwarning("Input Error", "Please Select Date of regn ", parent=self.vpage)
            return False
        elif (self.v1.get() == "Choose center") or (self.v1.get() == "No center Available"):
            messagebox.showwarning("Input Error", "Please Select Center ", parent=self.vpage)
            return False
        elif (self.v2.get() == 'Choose Result'):
            messagebox.showwarning("Input Error", "Please Select Result ", parent=self.vpage)
            return False
        elif not (self.t7.get().isdigit()) or len(self.t7.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid RPM (max)", parent=self.vpage)
            return False
        elif not (self.t8.get().isdigit()) or len(self.t8.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid RPM (min)", parent=self.vpage)
            return False
        elif not (self.t9.get().isdigit()) or len(self.t9.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid km ", parent=self.vpage)
            return False
        elif not (self.t10.get().isdigit()) or len(self.t10.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid HSU% ", parent=self.vpage)
            return False
        elif not (self.t11.get().isdigit()) or len(self.t11.get()) < 1:
            messagebox.showwarning("Validation Check", "Enter valid Temperature ", parent=self.vpage)
            return False

        return True

if __name__ == '__main__':
    d_window = Tk()
    Test(d_window)
    d_window.mainloop()
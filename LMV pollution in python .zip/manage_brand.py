from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Treeview
from details import *
import pymysql


class Brand:
    def __init__(self,parent):
        self.brand = StringVar()
        self.bpage = Toplevel(parent)
        self.header = Label(self.bpage,text='Manage Brand',font=("Cooper Black",50,'bold','underline'),anchor='center')
        self.l1 = Label(self.bpage,text='Brand',font=("Bahnschrift SemiBold SemiConden",14))
        self.t1 = Entry(self.bpage,width=30)
        self.b1 = Button(self.bpage,text='Submit',command=self.Add_Brand)
        self.b2 = Button(self.bpage, text='Delete',command=self.Delete)
        self.b3 = Button(self.bpage, text='Update',command=self.update)
        self.b4 = Button(self.bpage, text='Search',command=self.search)
        self.b5 = Button(self.bpage,text='Clear',command=self.clear)
        self.table = Frame(self.bpage)
        self.mytable = Treeview(self.table,columns='c1',height=12)
        self.mytable.heading('c1',text='Brand Name')
        self.mytable['show'] = 'headings'
        self.mytable.column('#1',width=300, anchor='center')
        self.mytable.pack()
        self.mytable.bind("<ButtonRelease-1>", lambda e: self.fetch())

        x1 = 10
        y1 = 140
        xd = 200
        yd = 70
        self.header.place(x=0, y=0)

        self.l1.place(x=x1, y=y1)
        self.t1.place(x=x1 + xd, y=y1+5)
        self.b4.place(x=x1+xd+xd+20,y=y1)

        y1+=yd
        y1 += 30
        self.b1.place(x=x1 + xd, y=y1)
        self.b2.place(x=x1, y=y1)
        self.b3.place(x=x1+xd+xd+20,y=y1)
        y1 += yd
        y1 += 30
        self.table.place(x=x1, y=y1)
        self.b5.place(x=x1+xd+xd+20,y=y1)


        self.bpage.mainloop()
    def Get_Connection(self):
        try:
            self.conn = pymysql.Connect(host=myhost,db=mydb,user=myuser,password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connnection Error ","Database Connection error"+str(e),parent= self.bpage)

    def Add_Brand(self):
        if self.validation() == False:
            return
        self.Get_Connection()
        try:
            qry = "insert into brand values(%s)"
            row_count = self.curr.execute(qry,self.t1.get())
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success", "Brand submitted ,successfully", parent=self.bpage)
                self.clear()
            else:
                messagebox.showwarning("Failure", "Brand not Saved", parent=self.bpage)
        except Exception as e:
            messagebox.showerror("Query error","Query error :"+str(e),parent = self.bpage)




    def clear(self):
        self.t1.delete(0,END)
        self.brand = ""
        self.mytable.delete(*self.mytable.get_children())


    def update(self):
        if self.validation() == False:
            return
        self.Get_Connection()
        try:

            qry = "update brand set brand = %s where brand = %s"
            row_count = self.curr.execute(qry,(self.t1.get(),self.brand))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Succes","Brand updated Successfully",parent = self.bpage)
                self.clear()
            else:
                messagebox.showwarning("Failure","Brand not Updated",parent = self.bpage)
        except Exception as e:
            messagebox.showerror("Query error","Query error :"+str(e),parent = self.bpage)



    def search(self):
        self.Get_Connection()
        try:
            qry = "select * from brand where brand like %s"
            row_count = self.curr.execute(qry,(self.t1.get()+'%'))
            data = self.curr.fetchall()
            if data:
                self.mytable.delete(*self.mytable.get_children())
                for val in data:
                    self.mytable.insert("",END,values=val)
            else:
                messagebox.showwarning("Failure", "Brand not Found", parent = self.bpage)
        except Exception as e:
            messagebox.showerror("Query error", "Query error :" + str(e), parent=self.bpage)

    def Delete(self):
        if self.validation() == False:
            return
        self.Get_Connection()
        ans = messagebox.askquestion("Confirmation","Do you really want to delete ?",parent = self.bpage)
        if ans == 'yes':
            try:

                qry = "Delete from brand where brand = %s"
                row_count = self.curr.execute(qry, self.t1.get())
                self.conn.commit()
                if row_count == 1:
                    messagebox.showinfo("Succes","Brand Deleted Successfully",parent = self.bpage)
                    self.clear()
                else:
                    messagebox.showwarning("Failure", "Brand not Found", parent=self.bpage)
            except Exception as e:
                messagebox.showerror("Query error", "Query error :" + str(e), parent=self.bpage)

    def fetch(self):
        id = self.mytable.focus()
        items = self.mytable.item(id)
        myvalues = items['values']
        pk = myvalues[0]
        self.brand = pk
        self.t1.insert(0,pk)



    def validation(self):
        if len(self.t1.get()) < 3:
            messagebox.showwarning("Validation error","Invalid Brand name",parent = self.bpage)
            return False
        return True
if __name__ == '__main__':
    demo = Tk()
    Brand(demo)
    demo.mainloop()
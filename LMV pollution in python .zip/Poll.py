from tkinter import messagebox
import pymysql
from details import *
class main:
    def Get_Connection(self):
        try:
            self.conn = pymysql.connect(host=myhost, db=mydb, user=myuser, password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connection Error", "Database connection Error : " + str(e))

    def __init__(self):
        self.Get_Connection()
        try:
            qry = "select * from user"
            row_count = self.curr.execute(qry)
            data = self.curr.fetchall()
            if data:
                from login import Login
                Login()
            else:
                from create_admin import Admin
                Admin()
        except Exception as e:
            messagebox.showerror("Query Error", "Query Error :" + str(e))

if __name__ == '__main__':
    main()


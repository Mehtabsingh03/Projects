from sqlite3 import Date
from tkinter import *
from tkinter import Label
from tkcalendar import DateEntry
from tkinter.ttk import Combobox, Treeview
import pymysql
from tkinter import messagebox
from details import *

class  Admin:
    def __init__(self):

        self.vpage = Tk()
        w = self.vpage.winfo_screenwidth()
        h = self.vpage.winfo_screenheight()
        self.vpage.geometry("%dx%d+%d+%d" % (650,450,300,250))

        self.header = Label(self.vpage, text="Manage User" , font=("Cooper Black",50,'bold','underline'))
        self.l1 = Label(self.vpage, text = 'Id no.',font=("Bahnschrift SemiBold SemiConden",14))
        self.t1 = Label(self.vpage, text = '1',font=("Bahnschrift SemiBold SemiConden",14))
        self.l2 = Label(self.vpage,text = 'User Name',font=("Bahnschrift SemiBold SemiConden",14))
        self.l3 = Label(self.vpage,text= 'Password',font=("Bahnschrift SemiBold SemiConden",14))
        self.l4 = Label(self.vpage,text= 'DOB',font=("Bahnschrift SemiBold SemiConden",14))
        self.l5 = Label(self.vpage,text= 'Center',font=("Bahnschrift SemiBold SemiConden",14))
        self.l6 = Label(self.vpage,text= 'User_Type',font=("Bahnschrift SemiBold SemiConden",14))

        self.t2 = Entry(self.vpage, width=24)
        self.t3 = Entry(self.vpage, width=24,show='*')
        self.t4 = DateEntry(self.vpage, width=22, background='blue', foreground='white', borderwidth=2,
                            date_pattern="y-mm-dd")
        self.v1= StringVar()
        self.t5 = Combobox(self.vpage,textvariable=self.v1, width=22)
        self.v2 = StringVar()
        self.t6 = Combobox(self.vpage, textvariable=self.v2, width=22)
        self.Get_combo()
        self.t6.set('Admin')

        self.b4 = Button(self.vpage, text='Submit',command=self.add)

        x1 = 10
        y1 = 140
        xd = 200
        yd = 70
        yn = 40
        self.header.place(x=0,y=0)

        self.l1.place(x=x1,y=y1)
        self.t1.place(x=x1 + xd, y=y1)

        y1=y1 + yn
        self.l2.place(x=x1,y=y1)
        self.t2.place(x=x1 + xd, y=y1)
        y1 += yn
        self.l3.place(x=x1,y=y1)
        self.t3.place(x=x1 + xd, y=y1)

        y1 += yd
        self.l4.place(x=x1,y=y1)
        self.t4.place(x=x1 + xd,y=y1)

        y1 += yd
        self.l5.place(x=x1,y=y1)
        self.t5.place(x=x1+xd,y=y1)

        y1 += yd
        self.l6.place(x=x1,y=y1)
        self.t6.place(x=x1+xd,y=y1)

        y1 += yd
        y1 += 40
        self.b4.place(x=x1+xd,y=y1)
        self.vpage.mainloop()

    def Get_Connection(self):
            try:
                self.conn = pymysql.connect(host=myhost, db=mydb, user=myuser, password=mypassword)
                self.curr = self.conn.cursor()
            except Exception as e:
                messagebox.showerror("Connection Error", "Database connection Error : " + str(e), parent=self.vpage)

    def Get_combo(self):
        self.Get_Connection()
        try:
            qry = "select * from center"
            row_count = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.conn.commit()
            c_list=[]
            if data:
                self.t5.set("Choose center")
                for val in data:
                    c_list.append(val[0])
            else:
                self.t5.set("No Brands Available")
            self.t5.config(values=c_list)
        except Exception as e:
            messagebox.showerror("Query Error","Query Error :"+str(e),parent=self.vpage)


    def add(self):
        if self.validation() == False:
            return
        self.Get_Connection()

        try:
            qry="insert into user values(%s,%s,%s,%s,%s,%s)"
            row_count = self.curr.execute(qry,('1',self.t2.get(),self.t3.get(),self.t4.get_date(),self.v1.get(),self.v2.get()))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success","Admin submitted ,successfully",parent=self.vpage)
                self.vpage.destroy()
                from login import Login
                Login()
            else:
                messagebox.showwarning("Failure","Admin not submitted",parent=self.vpage)

        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.vpage)


    def validation(self):
        if (len(self.t1.get()) < 1):
            messagebox.showwarning("Validation Check", "Enter valid number \n atleats 1 charracters", parent=self.vpage)
            return False

        elif len(self.t2.get()) < 3 or not (self.t2.get().isalpha()):
            messagebox.showwarning("Validation Check", "Enter valid name \n atleats 3 charracters", parent=self.vpage)
            return False
        elif not len(self.t3.get()) != 5:
            messagebox.showwarning("Validation Check", "Enter atleast 4 charracters", parent=self.vpage)
            return False
        elif (len(self.t4.get()) == ""):
            messagebox.showwarning("Input Error", "Please Select DOB ", parent=self.vpage)
            return False
        elif (self.v1.get() == "Choose center") or (self.v1.get() == "No Center Available"):
            messagebox.showwarning("Input Error", "Please Select Brand ", parent=self.vpage)
            return False
        elif (self.v2.get() == 'Choose Type'):
            messagebox.showwarning("Input Error", "Please Select Model ", parent=self.vpage)
            return False
        return True

if __name__ == '__main__':
    Admin()
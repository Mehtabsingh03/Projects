from ctypes import alignment
from tkinter import *
from tkinter import Label
import pymysql
from tkinter import messagebox
from details import *
import os
from PIL import Image,ImageTk

from fpdf import FPDF

company = "POLLUTION UNDER CONTROL CERTIFICATE"
address = "Approved by Government of India"
contact = "98989898"

class  Final:
    def __init__(self,page,m,vehicle,image):
        self.vehicl = vehicle
        self.i_name = image

        self.vpage = Toplevel(page)
        self.header = Label(self.vpage, text="POLLUTION UNDER CONTROL CERTIFICATE",anchor='center',font=("Cooper Black", 30, 'bold', 'underline'))
        self.header2 = Label(self.vpage, text="Approved by Government of India",anchor='center',font=("Cooper Black",14, 'bold', 'underline'))
        self.l1 = Label(self.vpage, text='Test Number',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l2 = Label(self.vpage, text='Vehicle name',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l3 = Label(self.vpage, text='Customer name',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l4 = Label(self.vpage, text='Customer mobile',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l5 = Label(self.vpage, text='Date of regn',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l6 = Label(self.vpage, text='Brand',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l7 = Label(self.vpage, text='Model',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l8 = Label(self.vpage, text='Time',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l9 = Label(self.vpage, text='Date',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l10 = Label(self.vpage, text='Center',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l11 = Label(self.vpage, text='Result',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l12 = Label(self.vpage, text='Rpm(max)',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l13 = Label(self.vpage, text='Rpm(min)',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l14 = Label(self.vpage, text='Km',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l15 = Label(self.vpage, text='HSU',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.l16 = Label(self.vpage, text='Temperature',width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')

        self.b1 = Button(self.vpage, text='Print',command=self.print)

        self.t1 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t2 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t3 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t4 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t5 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t6 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t7 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t8 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t9 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t10 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t11 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t12 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t13 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t14 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t15 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')
        self.t16 = Label(self.vpage,width=24,anchor="w", font=("Bahnschrift SemiBold SemiConden", 14), borderwidth=2, relief='groove')

        self.img = Label(self.vpage, borderwidth=2, relief='groove')

        self.v1 = StringVar()
        self.v2 = StringVar()
        self.v3 = StringVar()
        self.v4 = StringVar()
        self.v5 = StringVar()
        self.v6 = StringVar()
        self.v7 = StringVar()
        self.v8 = StringVar()
        self.v9 = StringVar()
        self.v10 = StringVar()
        self.v11 = StringVar()
        self.v12 = StringVar()
        self.v13 = StringVar()
        self.v14 = StringVar()
        self.v15 = StringVar()
        self.v16 = StringVar()
        self.fetch(m)

        x1 = 10
        y1 = 180
        xd = 250
        yd = 70
        yn = 40
        self.header.place(x=200, y=0)
        self.header2.place(x=500,y=70)

        self.l1.place(x=x1, y=y1)
        self.t1.place(x=x1+xd, y=y1)
        self.l12.place(x=x1+xd+xd+xd, y=y1)
        self.t12.place(x=x1+xd+xd+xd+xd, y=y1)
        y1=y1+yn

        self.l2.place(x=x1, y=y1)
        self.t2.place(x=x1+xd, y=y1)
        self.l13.place(x=x1+xd+xd+xd, y=y1)
        self.t13.place(x=x1+xd+xd+xd+xd, y=y1)
        y1=y1+yn
        self.l3.place(x=x1, y=y1)
        self.t3.place(x=x1+xd, y=y1)
        self.l14.place(x=x1+xd+xd+xd, y=y1)
        self.t14.place(x=x1+xd+xd+xd+xd, y=y1)
        y1=y1+yn
        self.l4.place(x=x1, y=y1)
        self.t4.place(x=x1+xd, y=y1)
        self.l15.place(x=x1+xd+xd+xd, y=y1)
        self.t15.place(x=x1+xd+xd+xd+xd, y=y1)
        y1=y1+yn
        self.l5.place(x=x1, y=y1)
        self.t5.place(x=x1+xd, y=y1)
        self.l16.place(x=x1+xd+xd+xd, y=y1)
        self.t16.place(x=x1+xd+xd+xd+xd, y=y1)
        y1=y1+yn
        self.l6.place(x=x1, y=y1)
        self.t6.place(x=x1+xd, y=y1)
        y1=y1+yn
        self.l7.place(x=x1, y=y1)
        self.t7.place(x=x1+xd, y=y1)
        y1=y1+yn
        self.l8.place(x=x1, y=y1)
        self.t8.place(x=x1+xd, y=y1)
        y1=y1+yn
        self.l9.place(x=x1, y=y1)
        self.t9.place(x=x1+xd, y=y1)
        self.img.place(x=x1 + xd + xd + xd , y=y1, width=150, height=150)
        self.b1.place(x=x1+xd+xd+xd+xd,y=y1)
        y1=y1+yn
        self.l10.place(x=x1, y=y1)
        self.t10.place(x=x1+xd, y=y1)
        y1=y1+yn
        self.l11.place(x=x1, y=y1)
        self.t11.place(x=x1+xd, y=y1)
        self.vpage.mainloop()
    def Get_Connection(self):
            try:
                self.conn = pymysql.connect(host=myhost, db=mydb, user=myuser, password=mypassword)
                self.curr = self.conn.cursor()
            except Exception as e:
                messagebox.showerror("Connection Error", "Database connection Error : " + str(e), parent=self.vpage)

    def fetch(self, m):

        self.img1 = Image.open("images//" + self.i_name)
        self.img1 = self.img1.resize((150, 150), Image.Resampling.LANCZOS)
        self.img2 = ImageTk.PhotoImage(self.img1)
        self.img.config(image=self.img2)

        self.Get_Connection()
        try:
            qry = "select * from test where test_no = %s"
            row_count = self.curr.execute(qry, (m))
            data = self.curr.fetchone()
            self.conn.commit()
            if data:
                self.t1.config(text=data[0])
                self.v1.set(value=data[0])
                self.v2.set(value=self.vehicl)
                self.t2.config(text=self.vehicl)
                try:
                    qry2 = "select * from vehicle where v_name = %s"
                    row_count = self.curr.execute(qry2,(self.vehicl))
                    dat = self.curr.fetchone()
                    self.conn.commit()
                    if dat:
                        self.t3.config(text=dat[1])
                        self.t4.config(text=dat[2])
                        self.t5.config(text=dat[3])
                        self.t6.config(text=dat[4])
                        self.t7.config(text=dat[5])
                        self.v3.set(value=dat[1])
                        self.v4.set(value=dat[2])
                        self.v5.set(value=dat[3])
                        self.v6.set(value=dat[4])
                        self.v7.set(value=dat[5])

                    else:
                        messagebox.showwarning("Failure", "Vehicle not found", parent=self.vpage)
                except Exception as b:
                    messagebox.showerror("Query Error", "Query error :" + str(b), parent=self.vpage)
                self.t8.config(text=data[2])
                self.t9.config(text=data[3])
                self.t10.config(text=data[4])
                self.t11.config(text=data[5])
                self.t12.config(text=data[6])
                self.t13.config(text=data[7])
                self.t14.config(text=data[8])
                self.t15.config(text=data[9])
                self.t16.config(text=data[10])
                self.v8.set(value=data[2])
                self.v9.set(value=data[3])
                self.v10.set(value=data[4])
                self.v11.set(value=data[5])
                self.v12.set(value=data[6])
                self.v13.set(value=data[7])
                self.v14.set(value=data[8])
                self.v15.set(value=data[9])
                self.v16.set(value=data[10])


            else:
                messagebox.showwarning("Failure", "Test not found", parent=self.vpage)
        except Exception as e:
            messagebox.showerror("Query Error", "Query error :" + str(e), parent=self.vpage)



    def print(self):
        pdf = my_cust_PDF()
        data = [['Vehicle Name', self.v2.get(),' ','Rpm (min)',self.v13.get()],
                ['Customer Name', self.v3.get(),'','Km',self.v14.get()],
                ['Customer Moblie', self.v4.get(),'','HSU',self.v15.get()],
                ['Date of regn', self.v5.get(),'','Temperature',self.v16.get()],
                ['Brand', self.v6.get()],
                ['Model', self.v7.get()],
                ['Time', self.v8.get()],
                ['Date', self.v9.get()],
                ['Center', self.v10.get(),"","Authorized Signature"],
                ['Result', self.v11.get()]]

        headings = ['Test Number', self.v1.get(),"","Rpm (max)",self.v12.get()]

        pdf.print_chapter(data, headings)
        pdf.output('pdf_file1.pdf')
        os.system('explorer.exe "pdf_file1.pdf"')
class my_cust_PDF(FPDF):
    def header(self):
        self.set_text_color(0, 0, 0)
        self.set_font("Helvetica", 'B', 24)
        w = self.get_string_width(company) + 6
        self.set_x((-200 - w) / 2)
        self.cell(w, 9, company)
        self.ln(10)  # line break

        self.set_font("Arial", 'B', 14)
        self.set_text_color(169,169,169)
        w = self.get_string_width(address) + 6
        self.set_x((210 - w) / 2)
        self.cell(w, 9, address)
        self.ln(8)

        w = self.get_string_width(contact) + 6
        self.set_x((210 - w) / 2)
        self.cell(w, 9, contact)
        self.ln(5)

        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(128)
        self.cell(0, 10, 'Page ' + str(self.page_no()), 0, 0, 'C')

    def chapter_content(self, data, headings):

        self.set_fill_color(200, 220, 255)
        self.ln()
        self.ln()

        self.set_font('Arial', 'B', 11)
        spacing = 1
        col_width = self.w / 5  # 9 = no of columns +1 to adjust columns to screen
        row_height = 11 + 2

        # Table heading
        for i in headings:  # for headings
            self.cell(col_width, row_height * spacing, txt=i, border=3)
        self.ln(row_height * spacing)

        # table body
        self.set_font('Arial', '', 11)
        for row in data:
            for item in row:
                self.cell(col_width, row_height * spacing, txt=str(item), border=3)
            self.ln(row_height * spacing)
        # Line break

        self.ln(2)

        # Mention in italics
        self.ln()
        self.ln()
        self.ln()
        self.set_font('', 'I')
        text1 = '(---------------------  end of page  -----------------------)'
        w = self.get_string_width(text1) + 6
        self.set_x((210 - w) / 2)
        self.cell(0, 6, text1)

    def print_chapter(self, data, headings):
        self.add_page()
        self.chapter_content(data, headings)

if __name__ == '__main__':
    d_window = Tk()
    Final(d_window,2,'default.jpg')
    d_window.mainloop()
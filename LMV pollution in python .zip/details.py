myhost = "localhost"
mydb = "poll"
myuser = "root"
mypassword = ""
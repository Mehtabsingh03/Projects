from tkinter import *
from sqlite3 import Date, Time
from tkinter import messagebox
from tkinter.ttk import Treeview
from details import *
from tkcalendar import DateEntry
import pymysql


class Report:
    def __init__(self,parent):
        self.brand = StringVar()
        self.bpage = Toplevel(parent)
        self.header = Label(self.bpage,text='Manage Report',font=("Cooper Black",50,'bold','underline'),anchor='center')
        self.l1 = Label(self.bpage,text='Brand',font=("Bahnschrift SemiBold SemiConden",14))
        self.l2 = Label(self.bpage,text='Brand',font=("Bahnschrift SemiBold SemiConden",14))
        self.t1 = DateEntry(self.bpage, width=22, background='blue', foreground='white', borderwidth=2,date_pattern="y-mm-dd")
        self.t2 = DateEntry(self.bpage, width=22, background='blue', foreground='white', borderwidth=2,
                            date_pattern="y-mm-dd")
        self.b4 = Button(self.bpage, text='Search',command=self.fetch)
        self.b5 = Button(self.bpage,text='Clear',command=self.clear)
        self.table = Frame(self.bpage)
        self.mytable = Treeview(self.table, columns=('c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8','c9','c10','c11'), height=10)
        self.mytable.heading('c1', text='Test No')
        self.mytable.heading('c2', text='Vehilce Name')
        self.mytable.heading('c3', text='time')
        self.mytable.heading('c4', text='Date')
        self.mytable.heading('c5', text='Center')
        self.mytable.heading('c6', text='Result')
        self.mytable.heading('c7', text='RPM(max)')
        self.mytable.heading('c8', text='RPM(min)')
        self.mytable.heading('c9', text='KM')
        self.mytable.heading('c10', text='HSU')
        self.mytable.heading('c11', text='TEMP')

        self.mytable['show'] = 'headings'
        self.mytable.column("#1", width=80, anchor='center')
        self.mytable.column("#2", width=100, anchor='center')
        self.mytable.column("#3", width=100, anchor='center')
        self.mytable.column("#4", width=100, anchor='center')
        self.mytable.column("#5", width=100, anchor='center')
        self.mytable.column("#6", width=100, anchor='center')
        self.mytable.column("#7", width=100, anchor='center')
        self.mytable.column("#8", width=100, anchor='center')
        self.mytable.column("#9", width=100, anchor='center')
        self.mytable.column("#10", width=100, anchor='center')
        self.mytable.column("#11", width=100, anchor='center')
        self.mytable.pack()

        x1 = 10
        y1 = 140
        xd = 200
        yd = 70
        self.header.place(x=0, y=0)

        self.l1.place(x=x1, y=y1)
        self.t1.place(x=x1 + xd, y=y1+5)
        self.l2.place(x=x1+xd+xd+xd, y=y1)
        self.t2.place(x=x1+xd+xd+xd+xd, y=y1+5)
        self.b4.place(x=x1+xd+xd+20,y=y1)
        y1 += yd
        self.b5.place(x=x1 + xd + xd + 20, y=y1)
        y1 += 30
        self.table.place(x=x1, y=y1)



        self.bpage.mainloop()
    def Get_Connection(self):
        try:
            self.conn = pymysql.Connect(host=myhost,db=mydb,user=myuser,password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connnection Error ","Database Connection error"+str(e),parent= self.bpage)


    def clear(self):
        self.t1.set_date(Date.today())
        self.t2.set_date(Date.today())
        self.mytable.delete(*self.mytable.get_children())

    def fetch(self):
        if self.validation() == False:
            return
        self.Get_Connection()
        try:
            qry="select * from test where date between %s and %s "
            row_count = self.curr.execute(qry,(self.t1.get_date(),self.t2.get_date()))
            data = self.curr.fetchall()
            self.conn.commit()
            if data:
                self.mytable.delete(*self.mytable.get_children())
                for val in data:
                    self.mytable.insert("", END, values=val)
            else:
                messagebox.showwarning("Failure", "Test not found between these dates", parent=self.bpage)
        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.bpage)



    def validation(self):
        if (len(self.t1.get()) == ""):
            messagebox.showwarning("Input Error", "Please Select Date", parent=self.bpage)
            return False
        elif (len(self.t2.get()) == ""):
            messagebox.showwarning("Input Error", "Please Select Date ", parent=self.bpage)
            return False
        return True
if __name__ == '__main__':
    demo = Tk()
    Report(demo)
    demo.mainloop()
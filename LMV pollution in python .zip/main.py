
def print_hi(name):

if __name__ == '__main__':
    print_hi('PyCharm')


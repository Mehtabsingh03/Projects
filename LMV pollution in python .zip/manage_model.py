from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox, Treeview
from details import *

import pymysql


class Model:
    def __init__(self,parent):
        self.mpage = Toplevel(parent)
        self.model = StringVar()
        self.header = Label(self.mpage, text='Manage Model', font=("Cooper Black", 50, 'bold', 'underline'))
        self.l1 = Label(self.mpage,text='Brand',font=("Bahnschrift SemiBold SemiConden",14))
        self.l2 = Label(self.mpage, text='Model', font=("Bahnschrift SemiBold SemiConden", 14))
        self.v1 = StringVar()
        self.c1 = Combobox(self.mpage,textvariable=self.v1)
        self.Get_combo()
        self.t1 = Entry(self.mpage, width=24)
        self.b1 = Button(self.mpage, text='Submit',command=self.add)
        self.b2 = Button(self.mpage, text='Delete',command=self.delete)
        self.b3 = Button(self.mpage, text='Update',command=self.update)
        self.b4 = Button(self.mpage, text='Search by Brand',command=self.search_brand)
        self.b5 = Button((self).mpage,text='Search by Model',command=self.search_model)
        self.b6 = Button((self).mpage, text='Clear',command=self.clear)
        self.table = Frame(self.mpage)
        self.mytable = Treeview(self.table,columns=('c1','c2'),height=12)
        self.mytable['show'] = 'headings'
        self.mytable.heading('c1',text='Brand name')
        self.mytable.heading('c2',text='Model name')
        self.mytable.column('#1',width=200,anchor="center")
        self.mytable.column('#2',width=200,anchor="center")
        self.mytable.bind("<ButtonRelease-1>", lambda e: self.fetch())
        self.mytable.pack()
        x1 = 10
        y1 = 140
        xd = 200
        yd = 70
        self.header.place(x=0, y=0)
        self.c1.place(x=x1+xd,y=y1)
        self.l1.place(x=x1, y=y1)

        self.b4.place(x=x1 + xd + xd + 20, y=y1)
        y1 += yd
        self.l2.place(x=x1,y=y1)
        self.t1.place(x=x1 + xd, y=y1 + 5)
        self.b5.place(x=x1+xd+xd+20,y=y1)
        y1 += yd
        self.b1.place(x=x1 + xd, y=y1)
        self.b2.place(x=x1, y=y1)
        self.b3.place(x=x1 + xd + xd + 20, y=y1)
        y1 += yd
        self.table.place(x=x1,y=y1)
        self.b6.place(x=x1 + xd + xd + 20, y=y1)
        self.mpage.mainloop()
    def get_connection(self):
        try:
            self.conn = pymysql.connect(host=myhost, db=mydb, user=myuser, password=mypassword)
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showerror("Connection Error","Database Connection error :"+str(e),parent=self.mpage)

    def Get_combo(self):
        self.get_connection()
        try:
            qry = "select * from brand"
            row_count = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.conn.commit()
            c_list=[]
            if data:
                self.c1.set("Choose Brand")
                for val in data:
                    c_list.append(val[0])
            else:
                self.c1.set("No Brands Available")
            self.c1.config(values=c_list)
        except Exception as e:
            messagebox.showerror("Query Error","Query Error :"+str(e),parent=self.mpage)

    def add(self):
        if self.validation() == False:
            return
        self.get_connection()

        try:
            qry="insert into model values(%s,%s)"
            row_count = self.curr.execute(qry,(self.v1.get(),self.t1.get()))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success","Model submitted ,successfully",parent=self.mpage)
                self.clear()
            else:
                messagebox.showwarning("Failure","Model not submitted",parent=self.mpage)

        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.mpage)



    def update(self):
        if self.validation() == False:
            return
        self.get_connection()

        try:
            qry="update model set brand = %s , model = %s where model = %s"
            row_count = self.curr.execute(qry,(self.v1.get(),self.t1.get(),self.model))
            self.conn.commit()
            if row_count == 1:
                messagebox.showinfo("Success","Model updated ,successfully",parent=self.mpage)
                self.clear()
            else:
                messagebox.showwarning("Failure","Model not updated",parent=self.mpage)

        except Exception as e:
            messagebox.showerror("Query Error","Query error :"+str(e),parent=self.mpage)



    def clear(self):
        self.mytable.delete(*self.mytable.get_children())
        self.t1.delete(0,END)
        self.Get_combo()
        self.model=''



    def delete(self):
        if self.validation() == False:
            return
        self.get_connection()
        ans = messagebox.askquestion("Confirmation ","Do you really want to delete?",parent=self.mpage)
        if ans == 'yes':
            try:
                qry = "delete from model where model = %s"
                row_count = self.curr.execute(qry, (self.t1.get()))
                self.conn.commit()
                if row_count == 1:
                    messagebox.showinfo("Success", "Model deleted ,successfully", parent=self.mpage)
                    self.clear()
                else:
                    messagebox.showwarning("Failure", "Model not deleted", parent=self.mpage)

            except Exception as e:
                messagebox.showerror("Query Error", "Query error :" + str(e), parent=self.mpage)

    def search_model(self):
        self.get_connection()
        try:
            qry = "select * from model where model like  %s"
            row_count = self.curr.execute(qry, (self.t1.get()+"%"))
            data = self.curr.fetchall()
            self.conn.commit()
            self.mytable.delete(*self.mytable.get_children())
            if data:
                for val in data:
                    self.mytable.insert("",END,values=val)
            else:
                messagebox.showwarning("Failure", "Model not found", parent=self.mpage)

        except Exception as e:
            messagebox.showerror("Query Error", "Query error :" + str(e), parent=self.mpage)


    def search_brand(self):
        self.get_connection()
        try:
            qry = "select * from model where brand like  %s"
            row_count = self.curr.execute(qry, (self.v1.get()+"%"))
            data = self.curr.fetchall()
            self.conn.commit()
            self.mytable.delete(*self.mytable.get_children())
            if data:
                for val in data:
                    self.mytable.insert("",END,values=val)
            else:
                messagebox.showwarning("Failure", "Model not avialabe", parent=self.mpage)

        except Exception as e:
            messagebox.showerror("Query Error", "Query error :" + str(e), parent=self.mpage)

    def fetch(self):

        id = self.mytable.focus()
        items = self.mytable.item(id)
        myvalues = items['values']
        m = myvalues[1]
        self.model = m
        self.get_connection()
        try:
            qry = "select * from model where model = %s"
            row_count = self.curr.execute(qry, (m))
            data = self.curr.fetchone()
            self.conn.commit()
            if data:
                self.clear()
                self.v1.set(data[0])
                self.t1.insert(0,data[1])
                self.model = m

            else:
                messagebox.showwarning("Failure", "Model not found", parent=self.mpage)

        except Exception as e:
            messagebox.showerror("Query Error", "Query error :" + str(e), parent=self.mpage)


    def validation(self):
        if self.v1.get() == "Choose Brand" or self.v1.get() == "No Brands Available":
            messagebox.showwarning("Input Error", "Please Select Brand ", parent=self.mpage)
            return False
        if len(self.t1.get()) < 3:
            messagebox.showwarning("Input Error", "Please write a appropriate model name", parent=self.mpage)
            return False
        return True


if __name__ == '__main__':
    demo = Tk()
    Model(demo)
    demo.mainloop()
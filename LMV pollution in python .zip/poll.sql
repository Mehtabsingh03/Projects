-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2022 at 09:34 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poll`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `Brand` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`Brand`) VALUES
('Ford'),
('Honda'),
('kia'),
('Mahindra'),
('Mercedes'),
('Rolls Royce');

-- --------------------------------------------------------

--
-- Table structure for table `center`
--

CREATE TABLE `center` (
  `center` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `center`
--

INSERT INTO `center` (`center`) VALUES
('2,hanumangarh,Rajasthan'),
('5,Ellenabad,Haryana');

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE `model` (
  `Brand` varchar(111) NOT NULL,
  `model` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`Brand`, `model`) VALUES
('Rolls Royce', 'phantom'),
('Mahindra', 'Scorpioo');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `test_no` int(111) NOT NULL,
  `v_name` varchar(111) NOT NULL,
  `time` varchar(111) NOT NULL,
  `date` date NOT NULL,
  `center` varchar(111) NOT NULL,
  `test_result` varchar(111) NOT NULL,
  `rpm_max` int(111) NOT NULL,
  `rpm_min` int(111) NOT NULL,
  `km` int(111) NOT NULL,
  `hsu` int(111) NOT NULL,
  `temp` int(111) NOT NULL,
  `i_name` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`test_no`, `v_name`, `time`, `date`, `center`, `test_result`, `rpm_max`, `rpm_min`, `km`, `hsu`, `temp`, `i_name`) VALUES
(2, 'hr44m44', '20:15:28', '2022-04-09', 'Choose center', 'Choose Result', 3422344, 524, 33, 3, 3, ''),
(5, '', '2022', '2022-04-10', 'Choose center', 'Choose Result', 0, 0, 0, 0, 0, '16496012541648712717Tulips.jpg'),
(6, '', '21:57:28', '2022-04-10', 'Choose center', 'Choose result', 0, 0, 0, 0, 0, 'default.png'),
(7, 'magiie12', '21:59:06', '2022-04-08', '5,Ellenabad,Haryana', 'Fail', 0, 2314213, 33, 3, 3, '1649608139default.jpg'),
(8, '', '22:02:07', '2022-04-10', 'Choose center', 'Choose result', 0, 0, 0, 0, 0, 'default.jpg'),
(9, 'rj31mm', '22:11:45', '2022-04-10', 'Choose center', 'Choose result', 0, 0, 0, 0, 0, 'default.jpg'),
(10, 'rj31mm', '22:12:09', '2022-04-10', 'Choose center', 'Choose result', 0, 0, 0, 0, 0, 'default.jpg'),
(11, 'rj31mm', '22:17:59', '2022-04-10', 'Choose center', 'Choose result', 0, 0, 0, 0, 0, 'default.jpg'),
(12, 'sam', '23:27:42', '2022-04-10', 'Choose center', 'Choose result', 1, 1, 1, 0, 0, 'default.jpg'),
(13, 'sam', '23:34:51', '2022-04-10', '1,hanumangarh,Rajasthan', 'Pass', 1, 1, 1, 1, 1, 'default.jpg'),
(14, 'rj55', '00:24:09', '2022-04-11', '1,hanumangarh,Rajasthan', 'Pass', 2322, 543, 32, 27, 27, '16496168451648712717Tulips.jpg'),
(15, 'rj31mm', '00:28:08', '2022-04-14', '1,hanumangarh,Rajasthan', 'Pass', 2311, 533, 24, 27, 27, 'default.jpg'),
(16, 'rj31mm', '00:28:59', '2022-04-14', '1,hanumangarh,Rajasthan', 'Pass', 2311, 533, 24, 27, 27, 'default.jpg'),
(17, 'rj55', '00:31:12', '2022-04-11', '5,Ellenabad,Haryana', 'Pass', 1, 1, 1, 1, 1, 'default.jpg'),
(18, 'rj55', '00:33:36', '2022-04-11', '5,Ellenabad,Haryana', 'Pass', 1, 1, 1, 1, 1, 'default.jpg'),
(19, 'rj55', '00:38:43', '2022-04-11', '1,hanumangarh,Rajasthan', 'Pass', 1, 1, 1, 1, 1, 'default.jpg'),
(20, 'rj55', '00:39:57', '2022-04-11', '5,Ellenabad,Haryana', 'Pass', 2, 2, 2, 2, 2, 'default.jpg'),
(21, 'rj55', '00:43:36', '2022-04-13', '5,Ellenabad,Haryana', 'Pass', 3, 3, 3, 3, 3, 'default.jpg'),
(22, 'rj55', '00:51:01', '2022-04-12', '2,hanumangarh,Rajasthan', 'Pass', 5, 5, 5, 5, 5, 'default.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_no` int(111) NOT NULL,
  `username` varchar(111) NOT NULL,
  `pass` int(111) NOT NULL,
  `dob` date NOT NULL,
  `center` varchar(111) NOT NULL,
  `type` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_no`, `username`, `pass`, `dob`, `center`, `type`) VALUES
(1, 'mehtab', 123, '2003-01-03', '1,hanumangarh,Rajasthan', 'Admin'),
(2, 'sam', 123, '2022-04-11', '2,hanumangarh,Rajasthan', 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `v_name` varchar(111) NOT NULL,
  `c_name` varchar(111) NOT NULL,
  `c_mobile` varchar(111) NOT NULL,
  `date` date NOT NULL,
  `Brand` varchar(111) NOT NULL,
  `model` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`v_name`, `c_name`, `c_mobile`, `date`, `Brand`, `model`) VALUES
('hr44m44', 'rahul', '0678987080', '2022-04-09', 'Rolls Royce', 'phantom'),
('rj31mm', 'Mehtab', '9680414001', '2022-04-20', 'Mahindra', 'Scorpioo'),
('rj55', 'Mehtab', '9680414001', '2022-04-20', 'Rolls Royce', 'phantom');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`Brand`);

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`model`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`test_no`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`v_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `test_no` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

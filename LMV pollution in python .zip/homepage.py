from tkinter import *
from tkinter import messagebox

import Manage_pass
from manage_brand import Brand
from manage_model import Model
from manage_vehicle import Vehicle
from Manage_pass import Pass
from Manage_user import User
from report import Report
from mange_center import Center
from Test import Test


class Homepage:
    def __init__(self,utype,uname):
        self.utype = utype
        self.uname = uname
        self.page = Tk()
        self.page.title("POLL")
        self.page.geometry("%dx%d+%d+%d"%(900,500,100,100))

        self.page.option_add('*TearOff',False)
        self.mnu = Menu()
        self.page.config(menu=self.mnu)
        self.mnu1 = Menu()
        self.mnu2 = Menu()
        self.mnu3 = Menu()
        self.mnu4 = Menu()
        self.mnu5 = Menu()
        self.mnu.add_cascade(menu=self.mnu1,label='Management Vehicle')
        self.mnu.add_cascade(menu=self.mnu2,label='Test')
        self.mnu.add_cascade(menu=self.mnu3,label='Report')
        self.mnu.add_cascade(menu=self.mnu4,label='User')
        self.mnu.add_cascade(menu=self.mnu5,label='Center')

        self.mnu1.add_command(label='Manage Brand', command=lambda:   Brand(self.page))
        self.mnu1.add_command(label='Manage Model', command=lambda:   Model(self.page))
        self.mnu1.add_command(label='Manage Vehicle', command=lambda:   Vehicle(self.page))
        self.mnu2.add_command(label='Test', command=lambda:    Test(self.page))
        self.mnu3.add_command(label='Report', command=lambda:   Report(self.page))

        self.mnu4.add_command(label='Logout', command=self.out)
        self.mnu4.add_command(label='Change Pass', command=lambda: Pass(self.page,self.uname))
        self.mnu4.add_command(label='Manage User', command=lambda: User(self.page))
        self.mnu5.add_command(label='Manage User', command=lambda: Center(self.page))
        print(self.utype)
        print(self.uname)
        if self.utype == 'Employee':

            self.mnu1.delete(0,1)
            self.mnu4.entryconfig(2,state='disable')
            self.mnu5.delete(0,END)

        self.page.mainloop()

    def out(self):
        ans = messagebox.askquestion("Confirmation","Do you want to LogOut?",parent = self.page)
        if ans == "yes":
            self.page.destroy()
            from  login import Login
            Login()

if __name__ == '__main__':
    Homepage('Employee','mehtab')
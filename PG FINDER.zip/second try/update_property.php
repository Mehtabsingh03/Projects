<?php
require 'header.php';

if(isset($_POST['search'])){
   include "dbcon.php";
   $id3 = $_GET['id'];
   $location2 = $_POST['location2'];
   $type2 = $_POST['type2'];
   $floor2 = $_POST['floor2'];
   $bhk2 = $_POST['bhk2'];
   $price2 = $_POST['price2'];
   $time2 = $_POST['time2'];
   $status2 = $_POST['status2'];
   $furnished2 = $_POST['furnished2'];
   $geezer2 = $_POST['geezer2'];
   $ro2 = $_POST['ro2'];
   $food2 = $_POST['food2'];
   $ac2 = $_POST['ac2'];
   $wifi2 = $_POST['wifi2'];
   $camera2 = $_POST['camera2'];
   $laundry2 = $_POST['laundry2'];
   $meter2 = $_POST['meter2'];
   $features2 = $_POST['features2'];


   // Update property in database
   $insertquery3 = "UPDATE `property` SET `city`='$location2',`type`='$type2',`floor_type`='$floor2',`bhk`='$bhk2',`price`='$price2',`time_bound`='$time2',`status`='$status2',`furnished`='$furnished2',`water_geezer`='$geezer2',`ro`='$ro2',`food`='$food2',`ac`='$ac2',`wifi`='$wifi2',`camera`='$camera2',`laundry`='$laundry2',`meter`='$meter2',`extra`='$features2' WHERE id='$id3'";
   $query3 = mysqli_query($con,$insertquery3);
    header('Location: profile.php');
    exit();
}
?>

<?php
$id2 = $_GET['id'];
include "dbcon.php";
$fetchquery2 = " SELECT * FROM `property` WHERE id='$id2'";
   $query2 = mysqli_query($con,$fetchquery2);
   ($result2 = mysqli_fetch_assoc($query2));?>
      <section class="filters" style="padding-bottom: 0;">
      <form action="" method="post" enctype="multipart/form-data">
         <div id="close-filter"><i class="fas fa-times"></i></div>
         <h3>Enter your property details</h3>
            <div class="flex">
            <div class="box">
            <p>Choose state <span>*</span></p>
            <select name="location2" class="input">
               <option value="<?php echo $result2['city']; ?>"><?php echo $result2['city']; ?></option>
                        <option value="Andra Pradesh">Andra Pradesh</option>
                        <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                        <option value="Assam">Assam</option>
                        <option value="Bihar">Bihar</option>
                        <option value="Chhattisgarh">Chhattisgarh</option>
                        <option value="Goa">Goa</option>
                        <option value="Gujarat">Gujarat</option>
                        <option value="Haryana">Haryana</option>
                        <option value="Himachal Pradesh">Himachal Pradesh</option>
                        <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                        <option value="Jharkhand">Jharkhand</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Kerala">Kerala</option>
                        <option value="Madya Pradesh">Madya Pradesh</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Manipur">Manipur</option>
                        <option value="Meghalaya">Meghalaya</option>
                        <option value="Mizoram">Mizoram</option>
                        <option value="Nagaland">Nagaland</option>
                        <option value="Orissa">Orissa</option>
                        <option value="Punjab">Punjab</option>
                        <option value="Rajasthan">Rajasthan</option>
                        <option value="Sikkim">Sikkim</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="Telangana">Telangana</option>
                        <option value="Tripura">Tripura</option>
                        <option value="Uttaranchal">Uttaranchal</option>
                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                        <option value="West Bengal">West Bengal</option>
                        <option disabled style="background-color:#aaa; color:#fff">UNION Territories</option>
                        <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                        <option value="Chandigarh">Chandigarh</option>
                        <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                        <option value="Daman and Diu">Daman and Diu</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Lakshadeep">Lakshadeep</option>
                        <option value="Pondicherry">Pondicherry</option>
            </select>
         </div>
               <div class="box">
                  <p>type</p>
                  <select name="type2" class="input"  required>
                        <option value="<?php echo $result2['type']; ?>"><?php echo $result2['type']; ?></option>
                        <option value="sharing" >sharing</option>
                        <option value="non-sharing">non-sharing</option>
                  </select>
               </div>
               <div class="box">
                  <p>floor type</p>
                  <select name="floor2" class="input" required>
                     <option value="<?php echo $result2['floor_type']; ?>"><?php echo $result2['floor_type']; ?></option>
                     <option value="flat">flat</option>
                     <option value="house">house</option>
                     <option value="room">shop</option>
                  </select>
               </div>
               <div class="box">
                  <p>how many BHK</p>
                  <select name="bhk2" class="input" required>
                     <option value="<?php echo $result2['bhk']; ?>"><?php echo $result2['bhk']; ?> BHK</option>
                     <option value="1">1 BHK</option>
                     <option value="2">2 BHK</option>
                     <option value="3">3 BHK</option>
                     <option value="4">4 BHK</option>
                     <option value="5">5 BHK</option>
                     <option value="6">6 BHK</option>
                     <option value="7">7 BHK</option>
                     <option value="8">8 BHK</option>
                     <option value="9">9 BHK</option>
                  </select>
               </div>
               <div class="box">
                  <p> Price</p>
                  <input type="text" name="price2" required maxlength="50" value="<?php echo $result2['price']; ?>" class="input">
               </div>
               <div class="box">
                  <p>Time boundation</p>
                  <select name="time2" class="input" required>
                     <option value="<?php echo $result2['time_bound']; ?>"><?php echo $result2['time_bound']; ?></option>
                     <option value="0">None</option>
                     <option value="8">8 pm</option>
                     <option value="9">9 pm</option>
                     <option value="10">10 pm</option>
                     <option value="11">11 pm</option>
                  </select>
               </div>
               <div class="box">
                  <p>status</p>
                  <select name="status2" class="input" required>
                  <option value="<?php echo $result2['status']; ?>"><?php echo $result2['status']; ?></option>
                     <option value="Co-ed">Co-ed</option>
                     <option value="Boys">Boys </option>
                     <option value="Girls">Girls</option>

                  </select>
               </div>
               <div class="box">
                  <p>furnished</p>
                  <select name="furnished2" class="input" required>
                     <option value="<?php echo $result2['furnished']; ?>"><?php echo $result2['furnished']; ?></option>
                     <option value="unfurnished">unfurnished</option>
                     <option value="furnished">furnished</option>
                     <option value="semi-furnished">semi-furnished</option>
                  </select>
               </div>
               <div class="box">
                  <p>water geezer</p>
                  <select name="geezer2" class="input" required>
                     <option value="<?php echo $result2['water_geezer']; ?>"><?php echo $result2['water_geezer']; ?></option>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>RO</p>
                  <select name="ro2" class="input" required>
                     <option value="<?php echo $result2['ro']; ?>"><?php echo $result2['ro']; ?></option>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>FOOD</p>
                  <select name="food2" class="input" required>
                     <option value="<?php echo $result2['food']; ?>"><?php echo $result2['food']; ?></option>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>AC</p>
                  <select name="ac2" class="input" required>
                     <option value="<?php echo $result2['ac']; ?>"><?php echo $result2['ac']; ?></option>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>WIFI</p>
                  <select name="wifi2" class="input" required>
                     <option value="<?php echo $result2['wifi']; ?>"><?php echo $result2['wifi']; ?></option>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>security camera</p>
                  <select name="camera2" class="input" required>
                     <option value="<?php echo $result2['camera']; ?>"><?php echo $result2['camera']; ?></option>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>Laundry</p>
                  <select name="laundry2" class="input" required>
                     <option value="<?php echo $result2['laundry']; ?>"><?php echo $result2['laundry']; ?></option>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>Electric meter</p>
                  <select name="meter2" class="input" required>
                     <option value="<?php echo $result2['meter']; ?>"><?php echo $result2['meter']; ?></option>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>Extra features </p>
                  <input type="text" name="features2" required maxlength="50" value="<?php echo $result2['extra']; ?>" class="input">
               </div>
               <input type="submit" value="update property" name="search" class="btn">
            </div>
      </form>
      </section>

   <!-- search filter section ends -->

   <div id="filter-btn"class="fas fa-filter"></div>


<?php require 'footer.php';?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<script>

document.querySelector('#filter-btn').onclick = () =>{
   document.querySelector('.filters').classList.add('active');
}

document.querySelector('#close-filter').onclick = () =>{
   document.querySelector('.filters').classList.remove('active');
}

</script>

</body>
</html>
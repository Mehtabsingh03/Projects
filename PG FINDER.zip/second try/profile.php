<?php require 'header.php';?>  

<!-- PROFILE SESSION START -->
<?php
      include "dbcon.php";
      $owner = $_SESSION['username'];
      $fetchquery = " SELECT * FROM `user` WHERE email='$owner'";
      $query = mysqli_query($con,$fetchquery);
      $result = mysqli_fetch_assoc($query);
         ?>

   <div>
      <div class="text-center">
         <center><img style="align-content: center;border-radius: 50%;"  width="300px" height="300px" src="<?php echo $result['pic'];?>" class="rounded" alt="...">
         <section><h1 style="font-size: 50px;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><?php echo $result['name'];?></h1></section>
         </center>
      </div>
   </div>
   <section class="view-property">
      <div class="details">
         <div class="info">
             <p><i class="fas fa-tag"></i><span><?php echo $result['email'];?></span></p>
             <p><i class="fas fa-user"></i><span><?php echo $result['govt_id'];?></span></p>
             <p><i class="fas fa-phone"></i><a href="tel:<?php echo $result['number'];?>"><?php echo $result['number'];?></a></p>
          </div>
          <h3 class="title">details</h3>
          <div class="flex">
             <div class="box">
                <p><i>AGE:</i><span><?php echo $result['age'];?></span></p>
                <p><i>GENDER :</i><span><?php echo $result['gender'];?></span></p>
                <p><i>ADDRESS :</i><span><?php echo $result['address'];?></span></p>
                <p><i>QUALIFICATION :</i><span><?php echo $result['qualification'];?></span></p>
                <p><i>BEHAVIOUR :</i><span><?php echo $result['behaviour'];?></span></p>
                <p><i>MARITAL STATUS :</i><span><?php echo $result['marital'];?></span></p>
             </div>
      </div>
   </section>
   <!-- PROFILE SESSION END -->

   <!-- LISTING SESSION START-->
<section class="listings">

   <h1 class="heading">listings</h1>

   <div class="box-container">
      <?php     
      $fetchquery2 = " SELECT * FROM `property` WHERE owner_id='$owner'";
      $query2 = mysqli_query($con,$fetchquery2);  
      while($result2 = mysqli_fetch_assoc($query2)){

         ?>

         <div class="box">
         <div class="admin">
            <h3><?php $user = $result['name'];echo substr($user, -1);?></h3>
            <div>
               <p><?php echo $result['name'];?></p>
               <span><?php echo $result['qualification'];?></span>
            </div>
         </div>
         <div class="thumb">
            <p class="total-images"><i class="far fa-image"></i><span></span></p>
            <p class="type"><span>PG</span><span>rent</span></p>
            <img src="<?php echo $result2['pic'];?>" alt="">
         </div>
         <h3 class="name"><?php echo $result2['id'];?></h3>
         <p class="location"><i class="fas fa-map-marker-alt"></i><span><?php echo $result2['city'];?></span></p>
         <div class="flex">
            <p><i class="fa-solid fa-house"></i><span><?php echo $result2['bhk'];?> bhk</span></p>
            <p><i class="fa-solid fa-sack-dollar"></i><span><?php echo $result2['price'];?></span></p>
            <p><i class="fa-solid fa-children"></i><span><?php echo $result2['status'];?></span></p>
         </div>
         <a href="view_property.php?id=<?php echo $result2['id'];?>" class="btn">view property</a>
         <a href="update_property.php?id=<?php echo $result2['id'];?>" class="btn">edit property</a>
         <a href="Delete_property2.php?id=<?php echo $result2['id'];?>" class="btn">Delete property</a>
      </div><?php
      }
      ?>

   </div>
</section>

<section class="listings">

   <h1 class="heading">wishlist</h1>

   <div class="box-container">
      <?php
            include "dbcon.php";
            $owner = $_SESSION['username'];
            $fetchquery4 = " SELECT * FROM `wishlist` WHERE email='$owner'";
            $query4 = mysqli_query($con,$fetchquery4);
            while($result4 = mysqli_fetch_assoc($query4)){
               $property_id = $result4['property_id'];
               $fetchquery5 = " SELECT * FROM `property` WHERE id='$property_id'";
               $query5 = mysqli_query($con,$fetchquery5);
               $result5 = mysqli_fetch_assoc($query5);
               $owner_mail = $result5['owner_id'];
               $fetchquery6 = " SELECT * FROM `user` WHERE email='$owner_mail'";
               $query6 = mysqli_query($con,$fetchquery6);
               $result6 = mysqli_fetch_assoc($query6);
               ?>
         <div class="box">
         <div class="admin">
            <h3><?php $user = $result6['name'];echo substr($user, -1);?></h3>
            <div>
               <p><?php echo $result6['name'];?></p>
               <span><?php echo $result6['qualification'];?></span>
            </div>
         </div>
         <div class="thumb">
            <p class="total-images"><i class="far fa-image"></i><span></span></p>
            <p class="type"><span>PG</span><span>rent</span></p>
            <img src="<?php echo $result5['pic'];?>" alt="">
         </div>
         <h3 class="name"><?php echo $result5['id'];?></h3>
         <p class="location"><i class="fas fa-map-marker-alt"></i><span><?php echo $result5['city'];?></span></p>
         <div class="flex">
            <p><i class="fa-solid fa-house"></i><span><?php echo $result5['bhk'];?> bhk</span></p>
            <p><i class="fa-solid fa-sack-dollar"></i><span><?php echo $result5['price'];?></span></p>
            <p><i class="fa-solid fa-children"></i><span><?php echo $result5['status'];?></span></p>
         </div>
         <a href="view_property.php?id=<?php echo $result5['id'];?>" class="btn">view property</a>
         <a href="Delete_property.php?id=<?php echo $result5['id'];?>" class="btn">Delete property</a>
      </div>
      <?php

            }
      ?>
            
   </div>
   </section>

<section class="listings">

<h1 class="heading">requests</h1>

<div class="box-container">
   <?php
         include "dbcon.php";
         $owner = $_SESSION['username'];
         $fetchquery7 = " SELECT * FROM `request` WHERE owner_id='$owner'";
         $query7 = mysqli_query($con,$fetchquery7);
         while($result7 = mysqli_fetch_assoc($query7)){
            $user = $result7['user_id'];
            $fetchquery8 = " SELECT * FROM `user` WHERE email='$user'";
            $query8 = mysqli_query($con,$fetchquery8);
            $result8 = mysqli_fetch_assoc($query8);
            ?>
      <div class="box">
      <div class="admin">
         <h3><?php $user = $result8['name'];echo substr($user, -1);?></h3>
         <div>
            <p><?php echo $result8['email'];?></p>
            <span><?php echo $result8['qualification'];?></span>
         </div>
      </div>
      <div class="thumb">
         <p class="total-images"><i class="far fa-image"></i><span></span></p>
         <img src="<?php echo $result8['pic'];?>" alt="">
      </div>
      <h3 class="name"><?php echo $result8['name'];?></h3>
      <p class="location"><i class="fas fa-map-marker-alt"></i><span><?php echo $result8['address'];?></span></p>
      <div class="flex">
         <p><i class="fa-solid fa-house"></i><span><?php echo $result8['marital'];?></span></p>
         <p><i class="fa-solid fa-sack-dollar"></i><span><?php echo $result8['number'];?></span></p>
         <p><i class="fa-solid fa-children"></i><span><?php echo $result8['gender'];?></span></p>
      </div>
      <p class="location"> Behaviour :<?php echo $result8['behaviour'];?></p>
      <p class="location"> AGE :<?php echo $result8['age'];?></p>
      <?php if ($result7['request_status'] =='pending') { ?>
      <a href="manage_request.php?user_id=<?php echo $result7['user_id'];?>" class="btn">Accept</a>
      <?php } ?>
      <a href="delete_request.php?user_id=<?php echo $result7['user_id'];?>" class="btn">Delete</a>
   </div>
   <?php
         }
   ?>  
   </div>
   </section>

   
   

<!-- listings section ends -->

<?php require 'footer.php';?>  


<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
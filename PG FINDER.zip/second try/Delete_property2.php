<?php
    include "dbcon.php";
    $id = $_GET['id'];
    $fetchquery = " DELETE FROM `property` WHERE id='$id'";
    $query = mysqli_query($con,$fetchquery);
    $fetchquery2 = " DELETE FROM `wishlist` WHERE property_id='$id'";
    $query2 = mysqli_query($con,$fetchquery2);
    $fetchquery3 = " DELETE FROM `request` WHERE property_id='$id'";
    $query3 = mysqli_query($con,$fetchquery3);
    header("location: profile.php");
?>
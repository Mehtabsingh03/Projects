<?php
      include "dbcon.php"; 
      session_start();
      $owner = $_SESSION['username'];
      $user = $_GET['user_id'];
      $status = 'accept';
      $insertquery13 = "UPDATE `request` SET request_status='$status' WHERE user_id='$user' AND owner_id='$owner'";
      $query13 = mysqli_query($con,$insertquery13);
      header("location: profile.php");
?>
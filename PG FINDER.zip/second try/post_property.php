<?php require 'header.php';
if(isset($_POST['search'])){
   include "dbcon.php";
   
   // Initialize an empty error message
   $error = '';
   
   // Get form data
   $location = $_POST['location'];
   $type = $_POST['type'];
   $floor = $_POST['floor'];
   $bhk = $_POST['bhk'];
   $price = $_POST['price'];
   $time = $_POST['time'];
   $status = $_POST['status'];
   $furnished = $_POST['furnished'];
   $geezer = $_POST['geezer'];
   $ro = $_POST['ro'];
   $food = $_POST['food'];
   $ac = $_POST['ac'];
   $wifi = $_POST['wifi'];
   $camera = $_POST['camera'];
   $laundry = $_POST['laundry'];
   $meter = $_POST['meter'];
   $features = $_POST['features'];
   $owner2 = $_SESSION['username'];
   $file = $_FILES['photo'];
   $filename = $file['name'];
   $filepath = $file['tmp_name'];
   $desfile = 'images/'.$filename;
   $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
   $file_type = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
   
   // Validate form data
   if(!in_array($file_type, $allowed_types)){
      $error = "Only JPG, JPEG, PNG, and GIF files are allowed";
   }elseif(!move_uploaded_file($filepath,$desfile)){
      $error = 'Error uploading file.';   
   }
   
   // If no errors, insert data into database
   if(empty($error)){
      $insertquery = "INSERT INTO `property`(`city`, `type`, `floor_type`, `bhk`, `price`, `time_bound`, `status`, `furnished`, `water_geezer`, `ro`, `food`, `ac`, `wifi`, `camera`, `laundry`, `meter`, `extra`, `owner_id`, `pic`) VALUES ('$location','$type','$floor','$bhk','$price','$time','$status','$furnished','$geezer','$ro','$food','$ac','$wifi','$camera','$laundry','$meter','$features','$owner2','$desfile')";
      $query = mysqli_query($con,$insertquery);
      header('Location: profile.php');
      exit();
   }
   
   // Display error message
   ?>
   <script>
      alert("<?php echo $error; ?>");
      </script>
      <?php
}
?>

<section class="filters" style="padding-bottom: 0;">
      <form action="" method="post" enctype="multipart/form-data">
         <div id="close-filter"><i class="fas fa-times"></i></div>
         <h3>Enter your property details</h3>
            <div class="flex">
            <div class="box">
            <p>Choose state <span>*</span></p>
            <select name="location" class="input">
               <option value="SelectState">Select State</option>
                        <option value="Andra Pradesh">Andra Pradesh</option>
                        <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                        <option value="Assam">Assam</option>
                        <option value="Bihar">Bihar</option>
                        <option value="Chhattisgarh">Chhattisgarh</option>
                        <option value="Goa">Goa</option>
                        <option value="Gujarat">Gujarat</option>
                        <option value="Haryana">Haryana</option>
                        <option value="Himachal Pradesh">Himachal Pradesh</option>
                        <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                        <option value="Jharkhand">Jharkhand</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Kerala">Kerala</option>
                        <option value="Madya Pradesh">Madya Pradesh</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Manipur">Manipur</option>
                        <option value="Meghalaya">Meghalaya</option>
                        <option value="Mizoram">Mizoram</option>
                        <option value="Nagaland">Nagaland</option>
                        <option value="Orissa">Orissa</option>
                        <option value="Punjab">Punjab</option>
                        <option value="Rajasthan">Rajasthan</option>
                        <option value="Sikkim">Sikkim</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="Telangana">Telangana</option>
                        <option value="Tripura">Tripura</option>
                        <option value="Uttaranchal">Uttaranchal</option>
                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                        <option value="West Bengal">West Bengal</option>
                        <option disabled style="background-color:#aaa; color:#fff">UNION Territories</option>
                        <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                        <option value="Chandigarh">Chandigarh</option>
                        <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                        <option value="Daman and Diu">Daman and Diu</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Lakshadeep">Lakshadeep</option>
                        <option value="Pondicherry">Pondicherry</option>
            </select>
         </div>
               <div class="box">
                  <p>Pictures</Picture></p>
                  <input type="file" name="photo" required placeholder="upload image " class="input">
               </div>
               <div class="box">
                  <p>type</p>
                  <select name="type" class="input" required>
                     <option value="sharing">sharing</option>
                     <option value="non-sharing">non-sharing</option>
                  </select>
               </div>
               <div class="box">
                  <p>floor type</p>
                  <select name="floor" class="input" required>
                     <option value="flat">flat</option>
                     <option value="house">house</option>
                     <option value="room">shop</option>
                  </select>
               </div>
               <div class="box">
                  <p>how many BHK</p>
                  <select name="bhk" class="input" required>
                     <option value="1">1 BHK</option>
                     <option value="2">2 BHK</option>
                     <option value="3">3 BHK</option>
                     <option value="4">4 BHK</option>
                     <option value="5">5 BHK</option>
                     <option value="6">6 BHK</option>
                     <option value="7">7 BHK</option>
                     <option value="8">8 BHK</option>
                     <option value="9">9 BHK</option>
                  </select>
               </div>
               <div class="box">
                  <p> Price</p>
                  <input type="text" required name="price" required maxlength="50" placeholder="enter price" class="input">
               </div>
               <div class="box">
                  <p>Time boundation</p>
                  <select name="time" class="input" required>
                     <option value="0">None</option>
                     <option value="8">8 pm</option>
                     <option value="9">9 pm</option>
                     <option value="10">10 pm</option>
                     <option value="11">11 pm</option>
                  </select>
               </div>
               <div class="box">
                  <p>status</p>
                  <select name="status" class="input" required>
                     <option value="Co-ed">Co-ed</option>
                     <option value="Boys">Boys </option>
                     <option value="Girls">Girls</option>

                  </select>
               </div>
               <div class="box">
                  <p>furnished</p>
                  <select name="furnished" class="input" required>
                     <option value="unfurnished">unfurnished</option>
                     <option value="furnished">furnished</option>
                     <option value="semi-furnished">semi-furnished</option>
                  </select>
               </div>
               <div class="box">
                  <p>water geezer</p>
                  <select name="geezer" class="input" required>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>RO</p>
                  <select name="ro" class="input" required>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>FOOD</p>
                  <select name="food" class="input" required>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>AC</p>
                  <select name="ac" class="input" required>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>WIFI</p>
                  <select name="wifi" class="input" required>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>security camera</p>
                  <select name="camera" class="input" required>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>Laundry</p>
                  <select name="laundry" class="input" required>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>Electric meter</p>
                  <select name="meter" class="input" required>
                     <option value="yes">Yes</option>
                     <option value="no">No</option>
                  </select>
               </div>
               <div class="box">
                  <p>Extra features (optional) </p>
                  <input type="text" name="features" required maxlength="50" placeholder="enter extra features" class="input">
               </div>
            </div>
            <input type="submit" value="post property" name="search" class="btn">
      </form>
   </section>

<div id="filter-btn" class="fas fa-filter"></div>





<?php require 'footer.php';?>  
<!-- custom js file link  -->
<script src="js/script.js"></script>
<script>

document.querySelector('#filter-btn').onclick = () =>{
   document.querySelector('.filters').classList.add('active');
}

document.querySelector('#close-filter').onclick = () =>{
   document.querySelector('.filters').classList.remove('active');
}

</script>

</body>
</html>
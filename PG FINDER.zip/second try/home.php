
<?php require 'header.php';?>  
<!-- home section starts  -->

<div class="home" >

   <section class="center">

      <form action="listings.php" method="GET">
         <h3>find your perfect home</h3>
         <div class="box">
            <p>Choose state <span>*</span></p>
            <select name="state" class="input">
               <option value="SelectState">Select State</option>
                        <option value="Andra Pradesh">Andra Pradesh</option>
                        <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                        <option value="Assam">Assam</option>
                        <option value="Bihar">Bihar</option>
                        <option value="Chhattisgarh">Chhattisgarh</option>
                        <option value="Goa">Goa</option>
                        <option value="Gujarat">Gujarat</option>
                        <option value="Haryana">Haryana</option>
                        <option value="Himachal Pradesh">Himachal Pradesh</option>
                        <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                        <option value="Jharkhand">Jharkhand</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Kerala">Kerala</option>
                        <option value="Madya Pradesh">Madya Pradesh</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Manipur">Manipur</option>
                        <option value="Meghalaya">Meghalaya</option>
                        <option value="Mizoram">Mizoram</option>
                        <option value="Nagaland">Nagaland</option>
                        <option value="Orissa">Orissa</option>
                        <option value="Punjab">Punjab</option>
                        <option value="Rajasthan">Rajasthan</option>
                        <option value="Sikkim">Sikkim</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="Telangana">Telangana</option>
                        <option value="Tripura">Tripura</option>
                        <option value="Uttaranchal">Uttaranchal</option>
                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                        <option value="West Bengal">West Bengal</option>
                        <option disabled style="background-color:#aaa; color:#fff">UNION Territories</option>
                        <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                        <option value="Chandigarh">Chandigarh</option>
                        <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                        <option value="Daman and Diu">Daman and Diu</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Lakshadeep">Lakshadeep</option>
                        <option value="Pondicherry">Pondicherry</option>
            </select>
         </div>
         <input type="submit" value="search property" name="search" class="btn">
      </form>
   </section>
</div>

<!-- home section ends -->
<?php

if(isset($_POST['search'])){
   $state = $_POST['state'];
}
?>
<!-- services section starts  -->

<section class="services">

   <h1 class="heading">our services</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/icon-1.png" alt="">
         <h3>Affordable Rents</h3>
         <p>PG Finder lists both single and shared rooms at affordable rents. Low security deposits and instant move-in options  are  available. All kind of PG's one can think of are listed.Dig in noww....</p>
      </div>

      <div class="box">
         <img src="images/icon-2.png" alt="">
         <h3>No Brokerage</h3>
         <p>Users can search for 1000+ PG accommodations without any brokerage or commission charges. This makes it convenient and cost-effective for those seeking accommodation</p>
      </div>

      <div class="box">
         <img src="images/icon-3.png" alt="">
         <h3>Homely Environment</h3>
         <p>PG Finder aims to provide a homely environment for residents. Facilities include safety measures, comfort, and hassle-free living. Homemade food options may also be available.</p>
      </div>

      <div class="box">
         <img src="images/icon-4.png" alt="">
         <h3>Community Builder</h3>
         <p> PG Finder isn’t just a website it’s a community. Let’s chat, explore, and discover the best PGs out there! to make your stay worthwhile and full of memories”</p>
      </div>

      <div class="box">
         <img src="images/icon-5.png" alt="">
         <h3>City-Wide Coverage</h3>
         <p>The application covers various cities in India, including Delhi, Chandigarh, Gurgaon, and Patiala etc. & New accommodations are added regularly to assist users</p>
      </div>

      <div class="box">
         <img src="images/icon-6.png" alt="">
         <h3> PG Owners</h3>
         <p>PG owners can list their properties on the platform to attract fresh leads & The application helps connect property owners with potential tenants.</p>
      </div>

   </div>

</section>

<!-- services section ends -->

<!-- listings section starts  -->

<section class="listings">

   <h1 class="heading">latest listings</h1>

   <div class="box-container">

   <?php
      include "dbcon.php";   
      $fetchquery2 = " SELECT * FROM `property` ORDER BY id DESC LIMIT 3";
      $query2 = mysqli_query($con,$fetchquery2);  
      while($result2 = mysqli_fetch_assoc($query2)){
         $email = $result2['owner_id'];
         $fetchquery = " SELECT * FROM `user` WHERE email='$email'";
         $query = mysqli_query($con,$fetchquery);
         $result = mysqli_fetch_assoc($query);
         
         ?>
         <div class="box">
         <div class="admin">
            <h3><?php $user = $result['name'];echo substr($user, -1);?></h3>
            <div>
               <p><?php echo $result['name'];?></p>
               <span><?php echo $result['qualification'];?></span>
            </div>
         </div>
         <div class="thumb">
            <p class="total-images"><i class="far fa-image"></i><span></span></p>
            <p class="type"><span>PG</span><span>rent</span></p>
            <img src="<?php echo $result2['pic'];?>" alt="">
         </div>
         <h3 class="name"><?php echo $result2['id'];?></h3>
         <p class="location"><i class="fas fa-map-marker-alt"></i><span><?php echo $result2['city'];?></span></p>
         <div class="flex">
            <p><i class="fa-solid fa-house"></i><span><?php echo $result2['bhk'];?> bhk</span></p>
            <p><i class="fa-solid fa-sack-dollar"></i><span><?php echo $result2['price'];?></span></p>
            <p><i class="fa-solid fa-children"></i><span><?php echo $result2['status'];?></span></p>
         </div>
         <a href="view_property.php?id=<?php echo $result2['id'];?>" class="btn">view property</a>
      </div>
      <?php
      }
      ?>

   </div>

</section>

<!-- listings section ends -->







<?php require 'footer.php';?>  

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
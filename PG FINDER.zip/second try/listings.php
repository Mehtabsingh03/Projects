
<?php require 'header.php';?>      
<section class="listings">

   <h1 class="heading">all listings</h1>

   <div class="box-container">
      <?php
      include "dbcon.php";
      $city = $_GET['state'];
      $fetchquery = " SELECT * FROM `property` WHERE city='$city'";
      $query = mysqli_query($con,$fetchquery);
      while($result = mysqli_fetch_assoc($query)){
         $email = $result['owner_id'];
         $fetchquery2 = " SELECT * FROM `user` WHERE email='$email'";
         $query2 = mysqli_query($con,$fetchquery2);
         $result2 = mysqli_fetch_assoc($query2);
         
         ?>
         <div class="box">
         <div class="admin">
            <h3><?php $user = $result2['name'];echo substr($user, -1);?></h3>
            <div>
               <p><?php echo $result2['name'];?></p>
               <span><?php echo $result2['qualification'];?></span>
            </div>
         </div>
         <div class="thumb">
            <p class="total-images"><i class="far fa-image"></i><span></span></p>
            <p class="type"><span>PG</span><span>rent</span></p>
            <img src="<?php echo $result['pic'];?>" alt="">
         </div>
         <h3 class="name"><?php echo $result['id'];?></h3>
         <p class="location"><i class="fas fa-map-marker-alt"></i><span><?php echo $result['city'];?></span></p>
         <div class="flex">
            <p><i class="fa-solid fa-house"></i><span><?php echo $result['bhk'];?> bhk</span></p>
            <p><i class="fa-solid fa-sack-dollar"></i><span><?php echo $result['price'];?></span></p>
            <p><i class="fa-solid fa-children"></i><span><?php echo $result['status'];?></span></p>
         </div>
         <?php
         if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){?>
            <a href="login.php" class="btn">view property</a><?php
         }
         else{
            ?>
            <a href="view_property.php?id=<?php echo $result['id'];?>" class="btn">view property</a>
         <?php
         }?>
      </div>
      <?php
      }
      ?>
   </div>
</section>


<!--listings section ends -->

<?php require 'footer.php';?>  












<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
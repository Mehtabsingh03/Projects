<?php
    include "dbcon.php";
    $id = $_GET['id'];
    $fetchquery = " DELETE FROM `wishlist` WHERE property_id='$id'";
    $query = mysqli_query($con,$fetchquery);
    header("location: profile.php");
?>

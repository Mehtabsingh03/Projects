
<?php require 'header.php';?> 

<!-- login section starts  -->

<?php 
include "dbcon.php";
if(isset($_POST['submit'])){
   $email = $_POST['email'];
   $pass = $_POST['pass'];
   
   $insertquery = "SELECT * FROM `user` WHERE email='$email' AND password='$pass'";
   $query = mysqli_query($con,$insertquery);
   $num = mysqli_num_rows($query);
   
   if($num == 1){
       session_start();
       $_SESSION['loggedin'] = 'true';
       $_SESSION['username'] = $email;
       header("location: home.php");
       exit; // exit after redirect
   } else {
       $_SESSION['error'] = 'wrong credentials';
       header("location: ".$_SERVER['PHP_SELF']); // redirect to same page
       exit; // exit after redirect
   }
}
?>

<!-- login section starts  -->

<section class="form-container">

   <form action="" method="post">
      <h3>welcome back!</h3>
      <input type="email" name="email" required maxlength="50" placeholder="enter your email" class="box">
      <input type="password" name="pass" required maxlength="20" placeholder="enter your password" class="box">
      <p>don't have an account? <a href="register.php">register new</a></p>
      <input type="submit" value="login now" name="submit" class="btn">
   </form>

   <?php if(isset($_SESSION['error'])):?>
       <script>
           alert("<?php echo $_SESSION['error'];?>");
       </script>
       <?php unset($_SESSION['error']);?>
   <?php endif;?>

</section>

<!-- login section ends -->

<?php require 'footer.php';?>  


<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
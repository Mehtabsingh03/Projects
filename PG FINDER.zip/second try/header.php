<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
<!-- header section starts  -->

<header class="header">

   <nav class="navbar nav-1">
      <section class="flex">
         <a href="home.php" class="logo"><i class="fas fa-house"></i>PG FINDER</a>
         <ul>
         <?php session_start();
         if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){?>
            <li><a href="login.php">post property<i class="fas fa-paper-plane"></i></a></li><?php
         }
         else{
            ?>
            <li><a href="post_property.php">post property<i class="fas fa-paper-plane"></i></a></li>
         <?php
         }?>
            
         </ul>
      </section>
   </nav>

   <nav class="navbar nav-2">
      <section class="flex">
         <div id="menu-btn" class="fas fa-bars"></div>

         <div class="menu">
            <ul>
               <li><a href="about.php">about us</i></a>
               </li>
               <li><a href="contact.php">contact us</i></a>
               </li>
               <li><a href="contact.php#faq">FAQ</i></a>
               </li>
            </ul>
         </div>
         <?php 
         if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){?>
         
         <ul>
            <li><a href="#">account <i class="fas fa-angle-down"></i></a>
               <ul>
                  <li><a href="login.php">login</a></li>
                  <li><a href="register.php">register</a></li>
               </ul>
            </li>
         </ul><?php
         }
         else{
            ?>
            <ul>
              <li><a href="#">account <i class="fas fa-angle-down"></i></a>
                <ul>
                      <li><a href="profile.php">profile</a></li>
                     <li><a href="logout.php">Log out</a></li>
                  </ul>
               </li>
            </ul>
         <?php
         }?>

      </section>
   </nav>

</header>

<!-- header section ends -->  
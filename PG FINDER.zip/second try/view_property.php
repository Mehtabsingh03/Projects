<?php require 'header.php';
    $idd = $_GET['id'];
    $user_me = $_SESSION['username'];
    include "dbcon.php";
    $fetchquery = " SELECT * FROM `property` WHERE id='$idd'";
    $query = mysqli_query($con,$fetchquery);
    $result = mysqli_fetch_assoc($query);
    $email = $result['owner_id'];
    $fetchquery2 = " SELECT * FROM `user` WHERE email='$email'";
    $query2 = mysqli_query($con,$fetchquery2);
    $result2 = mysqli_fetch_assoc($query2);
    $fetchquery3 = " SELECT * FROM `request` WHERE owner_id='$email' and user_id='$user_me'";
    $query3 = mysqli_query($con,$fetchquery3);
    $result3 = mysqli_fetch_assoc($query3);
    $status_request = '';
    if($result3){
      $status_request = $result3['request_status'];
    } ?>
    <section class="view-property">
        <div class="details">
            <?php if( $user_me == $email || $status_request == 'accept' ){ ?>
                <div class="thumb">
                    <div class="big-image">
                        <img src="<?php echo $result['pic'];?>" alt="">
                    </div>
                </div>
                <h3 class="name"><?php echo $result2['email'];?></h3>
                <p class="location"><i class="fas fa-map-marker-alt"></i><span><?php echo $result['city'];?></span></p>
                <div class="info">
                    <p><i class="fas fa-tag"></i><span><?php echo $result['price'];?></span></p>
                    <p><i class="fas fa-user"></i><span><?php echo $result2['name'];?> (owner)</span></p>
                    <p><i class="fas fa-phone"></i><a href="tel:<?php echo $result2['number'];?>"><?php echo $result2['number'];?></a></p>
                    <p><i class="fas fa-building"></i><span><?php echo $result['floor_type'];?> floor</span></p>
                    <p><i class="fas fa-house"></i><span><?php echo $result['type'];?></span></p>
                    <p><i class="fas fa-calendar"></i><span><?php echo $result2['qualification'];?></span></p>
                </div>
                <h3 class="title">details</h3>
                <div class="flex">
                    <div class="box">
                        <p><i>rooms :</i><span><?php echo $result['bhk'];?> bhk</span></p>
                        <p><i>Time boundation :</i><span><?php echo $result['time_bound'];?> </span></p>
                        <p><i>Status :</i><span><?php echo $result['status'];?> </span></p>
                        <p><i>Furnished :</i><span><?php echo $result['furnished'];?> </span></p>
                        <p><i>Water geezer :</i><span><?php echo $result['water_geezer'];?> </span></p>
                        <p><i>RO :</i><span><?php echo $result['ro'];?> </span></p>
                    </div>
                    <div class="box">
                        <p><i>FOOD :</i><span><?php echo $result['food'];?> </span></p>
                        <p><i>AC :</i><span><?php echo $result['ac'];?> </span></p>
                        <p><i>WIFI :</i><span><?php echo $result['wifi'];?> </span></p>
                        <p><i>Camera :</i><span><?php echo $result['camera'];?> </span></p>
                        <p><i>Laundry :</i><span><?php echo $result['laundry'];?> </span></p>
                        <p><i>Electric meter :</i><?php echo $result['meter'];?> </span></p>
                    </div>
                </div>
                <h3 class="title">EXTRA features</h3>
                <p class="description"><?php echo $result['extra'];?></p>

    <?php
    }
    else{ ?>
        <div class="thumb">
        <div class="big-image">
            <img src="<?php echo $result['pic'];?>" alt="">
        </div>
    </div>
    <h3 class="name">Email Hidden</h3>
    <p class="location"><i class="fas fa-map-marker-alt"></i><span><?php echo $result['city'];?></span></p>
    <div class="info">
        <p><i class="fas fa-tag"></i><span><?php echo $result['price'];?></span></p>
        <p><i class="fas fa-user"></i><span>Hidden (owner)</span></p>
        <p><i class="fas fa-phone"></i><a href="#">Hidden</a></p>
        <p><i class="fas fa-building"></i><span><?php echo $result['floor_type'];?> floor</span></p>
        <p><i class="fas fa-house"></i><span><?php echo $result['type'];?></span></p>
        <p><i class="fas fa-calendar"></i><span>Hidden</span></p>
    </div>
    <h3 class="title">details</h3>
                <div class="flex">
                    <div class="box">
                        <p><i>rooms :</i><span><?php echo $result['bhk'];?> bhk</span></p>
                        <p><i>Time boundation :</i><span><?php echo $result['time_bound'];?> </span></p>
                        <p><i>Status :</i><span><?php echo $result['status'];?> </span></p>
                        <p><i>Furnished :</i><span><?php echo $result['furnished'];?> </span></p>
                        <p><i>Water geezer :</i><span><?php echo $result['water_geezer'];?> </span></p>
                        <p><i>RO :</i><span><?php echo $result['ro'];?> </span></p>
                    </div>
                    <div class="box">
                        <p><i>FOOD :</i><span><?php echo $result['food'];?> </span></p>
                        <p><i>AC :</i><span><?php echo $result['ac'];?> </span></p>
                        <p><i>WIFI :</i><span><?php echo $result['wifi'];?> </span></p>
                        <p><i>Camera :</i><span><?php echo $result['camera'];?> </span></p>
                        <p><i>Laundry :</i><span><?php echo $result['laundry'];?> </span></p>
                        <p><i>Electric meter :</i><?php echo $result['meter'];?> </span></p>
                    </div>
                </div>
                <h3 class="title">EXTRA features</h3>
                <p class="description"><?php echo $result['extra'];?></p>
                <form action="" method="post">
                <?php   
                        $temp = 1;
                        $email2 = $_SESSION['username'];
                        $idd = $_GET['id'];
                      $fetchquery3 = " SELECT * FROM `wishlist`WHERE email='$email2'";
                      $query3 = mysqli_query($con,$fetchquery3);  
                      while($result3 = mysqli_fetch_assoc($query3)){
                        if($result3['property_id']==$idd){
                            $temp = 3;
                        }
                      }
                      if($temp == 1){     
                        ?>                        
                        <input type="submit" value="ADD to Wishlist" name="wishlist" class="inline-btn">
                        <?php                  
                      }
                      if($status_request == '' ){
                        ?>                        
                        <input type="submit" value="request owner" name="request" class="inline-btn">
                        <?php 
                      }?>
                </form>
    <?php
        } ?>
        </div>
    </section>    
    <?php
if(isset($_POST['wishlist'])){
    include "dbcon.php";
     $id4 = $_GET['id'];
     $user2 = $_SESSION['username'];
     $insertquery4 = "INSERT INTO `wishlist`(`email`, `property_id`) VALUES ('$user2','$id4')";
     $query4 = mysqli_query($con,$insertquery4);
     header("location: view_property.php?id=$id4");
     exit;
 }
 if(isset($_POST['request'])){
  include "dbcon.php";
  $idd = $_GET['id'];
  $status = "pending";
   $user3 = $_SESSION['username'];
   $owner3 = $result2['email'];
   $insertquery4 = "INSERT INTO `request`(`owner_id`, `user_id`, `request_status`) VALUES ('$owner3','$user3','$status')";
   $query4 = mysqli_query($con,$insertquery4);
   header("location: view_property.php?id=$idd");
   exit;
}
 ?>


<?php require 'footer.php';?>  

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>

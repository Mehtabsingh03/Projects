<?php
$server = "localhost";
$user = "root";
$password ="";
$db = "pg_finder";
$con = mysqli_connect($server,$user,$password,$db);
?>

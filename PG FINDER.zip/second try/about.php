
   
<?php require 'header.php';?>  

<!-- about section starts  -->

<section class="about">

   <div class="row">
      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>
      <div class="content">
         <h3>why choose us?</h3>
         <p>If you’re a PG owner, list your properties with us! PG Finder connects you with lots of fresh leads, making it easier to find tenants. PG Finder isn’t just about finding a place; it’s about creating a homely environment.</p>
         <a href="contact.html" class="inline-btn">contact us</a>
      </div>
   </div>

</section>

<!-- about section ends -->

<!-- steps section starts  -->

<section class="steps">

   <h1 class="heading">3 simple steps</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/step-1.png" alt="">
         <h3>search property</h3>
         <p>search property PG Finder is an online platform that simplifies the search for PG accommodations. Whether you’re a student, working professional, or someone seeking a homely environment</p>
      </div>

      <div class="box">
         <img src="images/step-2.png" alt="">
         <h3>contact agents</h3>
         <p>Contact agents are customer service professionals who handle a range of tasks related to customer inquiries. They interact with customers via emails, phone calls, and live chat messages.</p>
      </div>

      <div class="box">
         <img src="images/step-3.png" alt="">
         <h3>enjoy property</h3>
         <p>The user-friendly interface allows you to search for accommodations based on location, price, and amenities. Whether you’re looking for a cozy room near your college or a shared space with others.</p>
      </div>

   </div>

</section>

<!-- steps section ends -->

<!-- review section starts  -->

<section class="reviews">

   <h1 class="heading">Team mates</h1>

   <div class="box-container">

      <div class="box">
         <div class="user">
            <img src="images/mehtab.png" alt="">
            <div>
               <h3>Mehtab singh</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Hello and welcome to our site at PG Finder! I’m Mehtab Singh Sandhu.I’am owner of  this platform .WE tend to provide a home to our friends</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/mittali.jpg" alt="">
            <div>
               <h3>Mittali chugh</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>“Hello and welcome to our site at PG Finder! I’m Mittali. In our sight we ensuring that you find the safe and best PG according to your wishlist.”</p>
      </div>


      <div class="box">
         <div class="user">
            <img src="images/mansi.jpg" alt="">
            <div>
               <h3>Mansi chugh</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Hello! I’m mansi creator of the PG Finder web application. I’ve built this platform to help users find PGs across different states and cities.</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/khushi.jpg" alt="">
            <div>
               <h3>Khushi Arora</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Hello! I’m Khushi. In our sight we ensuring that you find the safe and best PG according to your wishlist.I’m excited to connect with you and enhance your experience.”</p>
      </div>
      <div class="box">
         <div class="user">
            <img src="images/pic-1.png" alt="">
            <div>
               <h3>john doe</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Adipisci voluptates delectus distinctio quam sequi error eum suscipit tempore inventore ex!</p>
      </div>
      <div class="box">
         <div class="user">
            <img src="images/pic-2.png" alt="">
            <div>
               <h3>johan doe</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Adipisci voluptates delectus distinctio quam sequi error eum suscipit tempore inventore ex!</p>
      </div>

   </div>

</section>

<!-- review section ends -->







<?php require 'footer.php';?>  

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
<?php require 'header.php';?> 
<section class="form-container">

   <form action="" method="post" enctype="multipart/form-data">
      <h3>create an account!  (all fields mandatory)</h3>
      <input type="text" name="name1" required required maxlength="50" placeholder="enter your name" class="box">
      <input type="email" name="email"  required required maxlength="50" placeholder="enter your email" class="box">
      <input type="text" name="number"  required required maxlength="10" placeholder="enter your mobile number" class="box">
      <input type="text" name="age" required maxlength="2" placeholder="enter your age" class="box">
      <div class="box">
        <input type="radio" name="gender" value="male" checked> Male
        <input type="radio" name="gender" value="female"> Female
        <input type="radio" name="gender" value="other"> Other		
      </div>
      <div class="box">
        <input type="radio" name="marital_status" value="Married"> Married
        <input type="radio" name="marital_status" value="Single"> Single
        <input type="radio" name="marital_status" value="Divorced"> Divorced	
      </div>
      <input type="text" required name="address" required maxlength="50" placeholder="enter your address " class="box">
      <input type="text"  required name="qualification" required maxlength="50" placeholder="enter your qualificaiton" class="box">
      <input type="text" required name="gov_id" required maxlength="50" placeholder="enter your GOVT ID" class="box">
      <input type="text" required name="behaviour" required maxlength="50" placeholder="enter about your behaviour" class="box">
      <input type="password" required name="pass" required maxlength="20" placeholder="enter your password" class="box">
      <input type="password" name="c_pass" required maxlength="20" placeholder="confirm your password" class="box">
      <input type="file" name="photo"  placeholder="upload image " class="box">
      <p>already have an account? <a href="login.php">Login now</a></p>
      <input type="submit" value="register now" name="submit" class="btn">
   </form>

</section>

<?php
include "dbcon.php";

if(isset($_POST['submit'])){
   $name1 = $_POST['name1'];
   $email = $_POST['email'];
   $number = $_POST['number'];
   $age = $_POST['age'];
   $gender = $_POST['gender'];
   $marital_status = $_POST['marital_status'];
   $address = $_POST['address'];
   $qualification = $_POST['qualification'];
   $gov_id = $_POST['gov_id'];
   $behaviour = $_POST['behaviour'];
   $pass = $_POST['pass'];
   $c_pass = $_POST['c_pass'];
   $photo = $_FILES['photo'];
   $filename = $photo['name'];
   $filepath = $photo['tmp_name'];
   $desfile = 'images/'.$filename;

   // Exception handling
   try {
      // Check if passwords match
      if($pass!= $c_pass){
         throw new Exception("Passwords do not match");
      }

      // Check if email already exists
      $query = "SELECT * FROM `user` WHERE email='$email'";
      $result = mysqli_query($con, $query);
      if(mysqli_num_rows($result) > 0){
         throw new Exception("Email already exists");
      }

      // Check if file is uploaded
      if($photo['size'] == 0){
         throw new Exception("Please upload an image");
      }

      // Check if file type is allowed
      $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
      $file_type = strtolower(pathinfo($photo['name'], PATHINFO_EXTENSION));
      if(!in_array($file_type, $allowed_types)){
         throw new Exception("Only JPG, JPEG, PNG, and GIF files are allowed");
      }

      // Insert data into database
      $insertquery = "INSERT INTO `user`(`name`, `email`, `number`, `age`, `gender`, `marital`, `address`, `qualification`, `govt_id`, `behaviour`, `password`, `pic`) VALUES  ('$name1', '$email', '$number', '$age', '$gender', '$marital_status', '$address', '$qualification', '$gov_id', '$behaviour', '$pass', '$desfile')";
      $query = mysqli_query($con, $insertquery);;
      
      if($query){
          session_start();
          $_SESSION['loggedin'] = 'true';
          $_SESSION['username'] = $email;
          header("location: home.php");
          exit; // exit after redirect
      } 

      // Success message
      echo "<script>alert('Registration successful')</script>";

   } catch (Exception $e) {
      // Error message
      echo "<script>alert('".$e->getMessage()."')</script>";
   }
}
?>

<!-- register section ends -->




<?php require 'footer.php';?>  


<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>